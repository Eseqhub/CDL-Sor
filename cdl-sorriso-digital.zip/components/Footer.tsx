import React, { useState } from 'react';
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone, Music2, CheckCircle2 } from 'lucide-react';
import CDLLogo from './CDLLogo';

const SocialButton: React.FC<{ Icon: React.ElementType, followers: string, href: string, color: string }> = ({ Icon, followers, href, color }) => {
  const [showCount, setShowCount] = useState(false);

  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault();
    
    if (showCount) return;

    setShowCount(true);

    setTimeout(() => {
        window.open(href, '_blank');
        setShowCount(false);
    }, 1500);
  };

  return (
    <a 
      href={href}
      onClick={handleClick}
      onMouseLeave={() => setShowCount(false)}
      className={`relative h-10 rounded-full flex items-center justify-center transition-all duration-500 overflow-hidden cursor-pointer ${showCount ? 'w-28 bg-white text-slate-900 shadow-lg scale-110' : 'w-10 bg-slate-800 text-slate-300 hover:bg-blue-600 hover:text-white hover:-translate-y-1'}`}
    >
      <div className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 ${showCount ? 'opacity-0' : 'opacity-100'}`}>
        <Icon className="w-5 h-5" />
      </div>
      
      <div className={`absolute inset-0 flex items-center justify-center gap-1 text-xs font-bold transition-opacity duration-300 ${showCount ? 'opacity-100' : 'opacity-0'}`}>
        <span className={color}>{followers}</span>
      </div>
    </a>
  );
};

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-300 pt-20 pb-10 border-t-4 border-yellow-500">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand */}
          <div className="space-y-6">
            <div className="flex flex-col items-start">
               <CDLLogo variant="white" className="h-16 w-auto mb-2" />
               <p className="text-sm leading-relaxed text-slate-400 max-w-xs mt-4">
                 Promovendo o desenvolvimento do comércio e defendendo os interesses dos lojistas de Sorriso-MT com inovação e compromisso.
               </p>
            </div>
            <div className="flex gap-3">
              <SocialButton Icon={Instagram} followers="45.2k" href="https://instagram.com" color="text-pink-600" />
              <SocialButton Icon={Facebook} followers="28k" href="https://facebook.com" color="text-blue-600" />
              <SocialButton Icon={Linkedin} followers="5k" href="https://linkedin.com" color="text-blue-800" />
              <SocialButton Icon={Music2} followers="150k" href="https://tiktok.com" color="text-black" />
            </div>
          </div>

          {/* Links */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">Navegação Rápida</h3>
            <ul className="space-y-3 text-sm">
              {['Institucional', 'Guia Comercial', 'Serviços', 'Notícias', 'Fale Conosco'].map(link => (
                 <li key={link}>
                     <a href="#" className="hover:text-yellow-400 transition-colors flex items-center gap-2">
                         <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                         {link}
                     </a>
                 </li>
              ))}
            </ul>
          </div>

          {/* Horários */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">Horário de Atendimento</h3>
            <div className="space-y-4 text-sm">
                {/* Segunda */}
                <div className="pb-3 border-b border-slate-800">
                    <div className="flex justify-between items-center mb-1">
                        <span className="text-yellow-400 font-bold">Segunda-feira</span>
                        <span className="text-[9px] bg-red-500/20 text-red-300 px-1.5 py-0.5 rounded uppercase font-bold tracking-wide">Horário Diferenciado</span>
                    </div>
                    <p className="text-white font-mono">08:00 às 11:30 | 13:00 às 17:30</p>
                </div>
                
                {/* Outros Dias */}
                <div className="space-y-2">
                    {['Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira'].map((day) => (
                        <div key={day} className="flex justify-between items-center">
                            <span className="text-slate-400">{day}</span>
                            <span className="text-slate-300 font-mono text-xs">07:30 - 11:30 | 13:00 - 17:30</span>
                        </div>
                    ))}
                </div>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-white font-bold text-lg mb-6">Fale Conosco</h3>
            <ul className="space-y-5 text-sm">
              <li className="flex items-start gap-3">
                <div className="p-2 bg-slate-800 rounded-lg shrink-0">
                    <MapPin className="w-5 h-5 text-yellow-500" />
                </div>
                <div>
                    <p className="text-white font-medium">Sede Principal</p>
                    <a 
                        href="https://maps.app.goo.gl/dNNqrg1mV4zMfuUH8" 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-slate-400 hover:text-white transition-colors block leading-relaxed"
                    >
                        Rua do Bosque, Nº 314, Centro<br/>
                        CEP: 78896-037, Sorriso-MT
                    </a>
                    <a 
                        href="https://maps.app.goo.gl/dNNqrg1mV4zMfuUH8" 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-xs text-blue-400 hover:text-blue-300 hover:underline mt-1 inline-block font-bold"
                    >
                        Ver localização no mapa →
                    </a>
                </div>
              </li>
              <li className="flex items-center gap-3">
                <div className="p-2 bg-slate-800 rounded-lg shrink-0">
                    <Phone className="w-5 h-5 text-yellow-500" />
                </div>
                <div>
                    <p className="text-white font-medium">Telefone Fixo</p>
                    <a href="tel:6635446080" className="text-slate-400 hover:text-white transition-colors font-mono tracking-wide">(66) 3544-6080</a>
                </div>
              </li>
              <li className="flex items-center gap-3">
                 <div className="p-2 bg-slate-800 rounded-lg shrink-0">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                </div>
                <div>
                    <p className="text-white font-medium">Central WhatsApp</p>
                    <a href="https://wa.me/5566996507301" target="_blank" rel="noreferrer" className="text-green-500 hover:text-green-400 transition-colors font-bold font-mono tracking-wide">
                        (66) 99650-7301
                    </a>
                </div>
              </li>
              <li className="flex items-center gap-3">
                 <div className="p-2 bg-slate-800 rounded-lg shrink-0">
                    <Mail className="w-5 h-5 text-yellow-500" />
                </div>
                <div>
                    <p className="text-white font-medium">Email</p>
                    <a href="mailto:centralatendimento@cdlsorriso.com.br" className="text-slate-400 hover:text-white truncate max-w-[180px] block" title="centralatendimento@cdlsorriso.com.br">centralatendimento@...</a>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-xs text-slate-500">
          <div className="flex flex-col gap-1">
              <p className="font-bold text-slate-400">CDL - CÂMARA DE DIRIGENTES LOJISTAS DE SORRISO</p>
              <div className="flex flex-col md:flex-row gap-1 md:gap-4">
                  <p>CNPJ: 04.533.476/0001-49</p>
                  <span className="hidden md:inline">|</span>
                  <p>&copy; {new Date().getFullYear()} Todos os direitos reservados.</p>
              </div>
          </div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white">Política de Privacidade</a>
            <a href="#" className="hover:text-white">Termos de Uso</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;