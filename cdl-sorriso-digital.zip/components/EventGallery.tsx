
import React, { useState } from 'react';
import { Camera, ArrowRight, X, ChevronLeft, ChevronRight, Download, Sliders, Image as ImageIcon, Maximize2 } from 'lucide-react';
import { GALLERY_IMAGES } from '../constants';

// Filtros CSS simulando presets
const FILTERS = [
  { id: 'none', label: 'Original', style: {} },
  { id: 'vivid', label: 'Vívido', style: { filter: 'contrast(1.1) saturate(1.3)' } },
  { id: 'bw', label: 'P&B', style: { filter: 'grayscale(100%) contrast(1.1)' } },
  { id: 'warm', label: 'Verão', style: { filter: 'sepia(0.2) saturate(1.2) hue-rotate(-10deg)' } },
  { id: 'cool', label: 'Frio', style: { filter: 'saturate(0.8) hue-rotate(10deg) brightness(1.1)' } },
  { id: 'vintage', label: 'Vintage', style: { filter: 'sepia(0.4) contrast(1.2) brightness(0.9)' } },
];

const EventGallery: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [activeFilter, setActiveFilter] = useState('none');
  const [showFilters, setShowFilters] = useState(false);

  const openLightbox = (index: number) => {
    setCurrentIndex(index);
    setIsOpen(true);
    setActiveFilter('none'); // Reset filter on open
  };

  const nextImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setCurrentIndex((prev) => (prev + 1) % GALLERY_IMAGES.length);
  };

  const prevImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    setCurrentIndex((prev) => (prev === 0 ? GALLERY_IMAGES.length - 1 : prev - 1));
  };

  // Simula o download da imagem com o filtro aplicado (Visualmente apenas, download real baixa o arquivo original nesta demo)
  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    const link = document.createElement('a');
    link.href = GALLERY_IMAGES[currentIndex].image;
    link.download = `CDL_Sorriso_Evento_${GALLERY_IMAGES[currentIndex].id}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const currentFilterStyle = FILTERS.find(f => f.id === activeFilter)?.style || {};

  return (
    <section className="py-20 bg-white" id="galeria">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-end mb-12">
            <div>
                <span className="text-blue-600 font-bold tracking-wider text-sm uppercase mb-2 block">Coberturas Sociais</span>
                <h2 className="text-3xl md:text-4xl font-bold text-slate-800">Galeria de Eventos</h2>
            </div>
            <button className="hidden md:flex items-center gap-2 text-slate-500 font-bold hover:text-blue-600 transition-colors">
                Ver todas as fotos <ArrowRight className="w-4 h-4" />
            </button>
        </div>

        {/* Grid de Miniaturas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 h-auto md:h-[500px]">
            {GALLERY_IMAGES.map((item, index) => (
                <div 
                    key={item.id} 
                    onClick={() => openLightbox(index)}
                    className={`relative group rounded-2xl overflow-hidden cursor-pointer shadow-md hover:shadow-xl transition-all duration-300 ${index === 0 ? 'md:col-span-2 md:row-span-2 h-64 md:h-full' : 'h-64 md:h-full'}`}
                >
                    <img src={item.image} alt={item.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                    
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity"></div>
                    
                    <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-md p-2 rounded-full opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
                        <Maximize2 className="w-5 h-5 text-white" />
                    </div>

                    <div className="absolute bottom-0 left-0 p-6 w-full transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300">
                        <div className="flex items-center gap-2 text-yellow-400 text-xs font-bold uppercase mb-1">
                            <Camera className="w-3 h-3" />
                            {item.date}
                        </div>
                        <h3 className={`${index === 0 ? 'text-2xl' : 'text-lg'} font-bold text-white mb-2`}>
                            {item.title}
                        </h3>
                        <div className="flex items-center gap-2 text-white/60 text-xs opacity-0 group-hover:opacity-100 transition-opacity delay-100">
                            <ImageIcon className="w-3 h-3" /> {item.count} fotos
                        </div>
                    </div>
                </div>
            ))}
        </div>
        
        <button className="w-full md:hidden mt-8 py-3 border border-slate-200 text-slate-600 font-bold rounded-xl">
            Ver todas as fotos
        </button>
      </div>

      {/* LIGHTBOX MODAL */}
      {isOpen && (
        <div className="fixed inset-0 z-[60] bg-black/95 backdrop-blur-sm flex items-center justify-center animate-in fade-in duration-300">
            {/* Controls */}
            <button onClick={() => setIsOpen(false)} className="absolute top-6 right-6 text-white/70 hover:text-white p-2 z-50">
                <X className="w-8 h-8" />
            </button>

            <button onClick={prevImage} className="absolute left-4 md:left-8 text-white/50 hover:text-white p-4 rounded-full hover:bg-white/10 transition-all z-50">
                <ChevronLeft className="w-10 h-10" />
            </button>
            <button onClick={nextImage} className="absolute right-4 md:right-8 text-white/50 hover:text-white p-4 rounded-full hover:bg-white/10 transition-all z-50">
                <ChevronRight className="w-10 h-10" />
            </button>

            {/* Main Image Area */}
            <div className="relative max-w-5xl max-h-[80vh] w-full px-4 flex flex-col items-center">
                <img 
                    src={GALLERY_IMAGES[currentIndex].image} 
                    alt="Evento" 
                    className="max-h-[70vh] w-auto object-contain rounded-lg shadow-2xl transition-all duration-300"
                    style={currentFilterStyle}
                />
                
                <div className="mt-6 text-center text-white">
                    <h3 className="text-xl font-bold">{GALLERY_IMAGES[currentIndex].title}</h3>
                    <p className="text-white/60 text-sm">{currentIndex + 1} de {GALLERY_IMAGES.length}</p>
                </div>

                {/* Toolbar */}
                <div className="mt-8 flex gap-4 bg-white/10 backdrop-blur-md p-3 rounded-2xl border border-white/20">
                    <button 
                        onClick={handleDownload}
                        className="flex items-center gap-2 px-4 py-2 bg-white text-black rounded-xl font-bold text-sm hover:bg-blue-50 transition-colors"
                    >
                        <Download className="w-4 h-4" /> Baixar HD
                    </button>
                    
                    <div className="w-px bg-white/20 mx-2"></div>
                    
                    <button 
                        onClick={() => setShowFilters(!showFilters)}
                        className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-sm transition-colors ${showFilters ? 'bg-blue-600 text-white' : 'text-white hover:bg-white/10'}`}
                    >
                        <Sliders className="w-4 h-4" /> Filtros
                    </button>
                </div>

                {/* Filter Presets Panel */}
                {showFilters && (
                    <div className="absolute bottom-24 bg-black/80 backdrop-blur-xl p-4 rounded-2xl border border-white/10 flex gap-4 overflow-x-auto max-w-full animate-in slide-in-from-bottom-4">
                        {FILTERS.map(filter => (
                            <button
                                key={filter.id}
                                onClick={() => setActiveFilter(filter.id)}
                                className={`flex flex-col items-center gap-2 min-w-[80px] group`}
                            >
                                <div 
                                    className={`w-16 h-16 rounded-lg overflow-hidden border-2 transition-all ${activeFilter === filter.id ? 'border-yellow-400 scale-110' : 'border-transparent group-hover:border-white/50'}`}
                                >
                                    <img 
                                        src={GALLERY_IMAGES[currentIndex].image} 
                                        className="w-full h-full object-cover"
                                        style={filter.style}
                                        alt={filter.label}
                                    />
                                </div>
                                <span className={`text-[10px] font-bold uppercase ${activeFilter === filter.id ? 'text-yellow-400' : 'text-white/70'}`}>
                                    {filter.label}
                                </span>
                            </button>
                        ))}
                    </div>
                )}
            </div>
        </div>
      )}
    </section>
  );
};

export default EventGallery;
