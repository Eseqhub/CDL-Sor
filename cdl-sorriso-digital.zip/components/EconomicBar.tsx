
import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Minus, Wheat, ShoppingBag, Activity, ChevronRight, ChevronLeft, Building2, Database, Sun } from 'lucide-react';

const DATA_GROUPS = [
  {
    id: 'agro',
    label: "Agronegócio",
    icon: Wheat,
    iconColor: "text-yellow-400",
    items: [
      { label: "Soja", value: "R$ 118,00", delta: "-0.5%", type: "down" },
      { label: "Milho", value: "R$ 38,50", delta: "Estável", type: "neutral" },
      { label: "Boi", value: "R$ 230,00", delta: "+1.2%", type: "up" },
    ]
  },
  {
    id: 'spc',
    label: "Raio-X SPC",
    icon: Database,
    iconColor: "text-blue-400",
    items: [
      { label: "Inadimplência", value: "3.5%", delta: "-0.2%", type: "down" },
      { label: "Recuperação", value: "R$ 2Mi", delta: "+5%", type: "up" },
      { label: "Consultas", value: "15.4k", delta: "+12%", type: "up" },
    ]
  },
  {
    id: 'retail',
    label: "Varejo",
    icon: ShoppingBag,
    iconColor: "text-purple-400",
    items: [
      { label: "Vendas", value: "+2.4%", delta: "Mensal", type: "up" },
      { label: "Ticket Médio", value: "R$ 145", delta: "+R$ 5", type: "up" },
    ]
  },
  {
    id: 'economy',
    label: "Economia",
    icon: Activity,
    iconColor: "text-green-400",
    items: [
      { label: "Dólar", value: "R$ 5,95", delta: "+0.2%", type: "up" },
      { label: "Selic", value: "11.25%", delta: "a.a.", type: "neutral" },
    ]
  }
];

const TAX_TYPES = [
    { label: "Total Geral", key: "total" },
    { label: "IPTU", key: "iptu" },
    { label: "ISS", key: "iss" },
    { label: "ITBI", key: "itbi" }
];

const EconomicBar: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [fade, setFade] = useState(true);
  
  // Impostômetro States
  const [taxValue, setTaxValue] = useState(185400500); 
  const [taxLabel, setTaxLabel] = useState(TAX_TYPES[0].label);

  // Time State
  const [time, setTime] = useState('');

  useEffect(() => {
    // Time updater
    const updateTime = () => {
        const now = new Date();
        setTime(now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }));
    };
    updateTime();
    const timeInterval = setInterval(updateTime, 60000); // Update every minute

    // Carousel updater
    const interval = setInterval(() => {
      nextGroup();
    }, 15000);

    // Impostometro label cycler
    const taxTypeInterval = setInterval(() => {
        setTaxLabel(prevLabel => {
            const currentIdx = TAX_TYPES.findIndex(t => t.label === prevLabel);
            const nextIdx = (currentIdx + 1) % TAX_TYPES.length;
            
            // Simulate distinct values
            let base = 185400500;
            if (nextIdx === 1) base = 45200100; 
            if (nextIdx === 2) base = 32100500; 
            if (nextIdx === 3) base = 12500000; 
            setTaxValue(base);
            
            return TAX_TYPES[nextIdx].label;
        });
    }, 5000);

    // Impostometro counter animation
    const taxValueInterval = setInterval(() => {
        setTaxValue(prev => prev + Math.floor(Math.random() * 150));
    }, 100);

    return () => {
        clearInterval(interval);
        clearInterval(taxTypeInterval);
        clearInterval(taxValueInterval);
        clearInterval(timeInterval);
    };
  }, [currentIndex]);

  const nextGroup = () => {
    setFade(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % DATA_GROUPS.length);
      setFade(true);
    }, 300);
  };

  const prevGroup = () => {
    setFade(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev === 0 ? DATA_GROUPS.length - 1 : prev - 1));
      setFade(true);
    }, 300);
  };

  const currentGroup = DATA_GROUPS[currentIndex];
  const GroupIcon = currentGroup.icon;

  const renderDelta = (delta: string, type: string) => {
    if (type === 'up') return <span className="text-green-400 text-[10px] flex items-center ml-1"><TrendingUp className="w-3 h-3 mr-0.5" /> {delta}</span>;
    if (type === 'down') return <span className="text-red-400 text-[10px] flex items-center ml-1"><TrendingDown className="w-3 h-3 mr-0.5" /> {delta}</span>;
    return <span className="text-slate-400 text-[10px] flex items-center ml-1"><Minus className="w-3 h-3 mr-0.5" /> {delta}</span>;
  };

  return (
    <div className="fixed top-0 left-0 w-full bg-slate-900 text-white text-xs border-b border-slate-800 z-50 h-14 shadow-md">
      <div className="container mx-auto px-2 h-full flex items-center justify-between relative">
        
        {/* Left: Controls, Group Label AND Weather/Time */}
        <div className="flex items-center gap-3 md:gap-4 z-10 bg-slate-900 pr-2 h-full flex-shrink-0 border-r border-slate-800 mr-2">
            {/* Weather/Time Widget */}
            <div className="hidden md:flex flex-col items-start justify-center pr-4 mr-2 border-r border-slate-800/50 h-3/4 my-auto">
                <div className="flex items-center gap-2 text-[10px] text-slate-400 mb-0.5 leading-none">
                    <span className="font-bold text-slate-300">SORRISO</span>
                    <span className="w-0.5 h-2.5 bg-slate-700"></span>
                    <span className="font-mono text-slate-300">{time}</span>
                </div>
                <div className="flex items-center gap-1.5 text-yellow-400 leading-none">
                    <Sun className="w-3.5 h-3.5 animate-pulse-soft" />
                    <span className="font-bold text-xs">32°C</span>
                    <span className="text-[10px] text-slate-500 font-medium">Ensolarado</span>
                </div>
            </div>

            {/* Navigation */}
            <div className="flex gap-1">
                <button onClick={prevGroup} className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"><ChevronLeft className="w-3 h-3" /></button>
                <button onClick={nextGroup} className="p-1 hover:bg-slate-800 rounded text-slate-400 hover:text-white transition-colors"><ChevronRight className="w-3 h-3" /></button>
            </div>
            
            {/* Category Label */}
            <div className={`flex items-center gap-2 font-bold transition-opacity duration-300 ${fade ? 'opacity-100' : 'opacity-0'}`}>
                <GroupIcon className={`w-4 h-4 ${currentGroup.iconColor} flex-shrink-0`} />
                <span className="uppercase tracking-wider text-slate-200 hidden sm:inline whitespace-nowrap">{currentGroup.label}</span>
            </div>
        </div>
        
        {/* Center: Scrolling Data */}
        <div className="flex-1 flex items-center overflow-hidden mx-2 min-w-0 mask-fade relative h-full">
          <div className={`flex items-center gap-6 md:gap-8 transition-all duration-500 overflow-x-auto no-scrollbar w-full px-4 ${fade ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}`}>
            {currentGroup.items.map((item, idx) => (
              <div key={idx} className="flex items-center gap-1.5 flex-shrink-0">
                <span className="text-slate-400">{item.label}:</span>
                <span className="font-mono font-bold text-white">{item.value}</span>
                {renderDelta(item.delta, item.type)}
              </div>
            ))}
          </div>
        </div>
        
        {/* Right Section: Impostômetro ONLY */}
        <div className="flex items-center h-full bg-slate-900 z-10 flex-shrink-0">
            <div className="flex items-center gap-3 justify-end border-l border-slate-800 pl-4 pr-2 h-full">
                <div className="hidden lg:flex p-1.5 bg-slate-800 rounded-lg">
                    <Building2 className="w-4 h-4 text-blue-400" />
                </div>
                <div className="flex flex-col items-end justify-center leading-tight">
                    <div className="flex items-center gap-1">
                        <span className="text-[9px] text-slate-400 uppercase tracking-wider">Arrecadação</span>
                        <span className="text-[9px] text-yellow-500 font-bold uppercase tracking-wider">({taxLabel})</span>
                    </div>
                    <div className="flex items-center gap-0.5 font-mono text-white font-bold text-sm md:text-base">
                        <span className="text-slate-500 text-xs mr-1">R$</span>
                        <span>
                            {new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(taxValue)}
                        </span>
                    </div>
                    <span className="text-[8px] text-slate-600">Fonte: Impostômetro</span>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default EconomicBar;
