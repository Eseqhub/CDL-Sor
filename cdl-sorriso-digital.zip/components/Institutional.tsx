
import React, { useState } from 'react';
import { Award, Target, Heart, ArrowRight } from 'lucide-react';
import { BOARD_MEMBERS, COLLABORATORS } from '../constants';
import { TeamMember, BoardMember } from '../types';

// Card Padronizado
const PersonCard: React.FC<{ person: BoardMember | TeamMember, type: 'board' | 'team' }> = ({ person, type }) => (
  <div className="group/card relative overflow-hidden rounded-2xl shadow-md hover:shadow-xl transition-all duration-500 bg-white h-full transform hover:-translate-y-2 w-52 flex-shrink-0">
      <div className="aspect-[3/4] overflow-hidden relative">
          <img 
              src={person.image} 
              alt={person.name} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover/card:scale-110 grayscale group-hover/card:grayscale-0" 
              style={{ objectPosition: 'top center' }} 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-blue-900/90 via-blue-900/20 to-transparent opacity-60 group-hover/card:opacity-80 transition-opacity"></div>
          
           {/* Badge */}
           <div className="absolute top-2 right-2">
               <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm ${type === 'board' ? 'bg-yellow-400 text-blue-900' : 'bg-white/90 text-blue-900'}`}>
                  {type === 'board' ? 'Diretoria' : 'Equipe'}
               </span>
          </div>
      </div>
      
      <div className="p-4 text-center relative bg-white border-t border-slate-50">
          <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-8 h-1 bg-yellow-400 rounded-full group-hover/card:w-16 transition-all duration-300"></div>
          <h3 className="text-base font-bold text-slate-800 leading-tight mb-1 group-hover/card:text-blue-700 transition-colors">{person.name}</h3>
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider line-clamp-2 h-8 flex items-center justify-center">{person.role}</p>
          {'department' in person && (
              <p className="text-blue-600 text-[9px] font-bold mt-1.5 bg-blue-50 inline-block px-1.5 py-0.5 rounded-md">{(person as TeamMember).department}</p>
          )}
      </div>
  </div>
);

const Institutional: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'entity' | 'board'>('entity');

  return (
    <section className="py-24 bg-slate-50" id="institucional">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
           <span className="text-yellow-500 font-bold tracking-wider text-xs uppercase mb-2 block">Quem Somos</span>
           <h2 className="text-3xl md:text-4xl font-bold text-slate-900">A Força do Lojista</h2>
        </div>

        {/* Tabs Navigation */}
        <div className="flex justify-center mb-16">
            <div className="bg-white p-1.5 rounded-full shadow-sm border border-slate-200 inline-flex gap-1">
                <button 
                    onClick={() => setActiveTab('entity')}
                    className={`px-8 py-3 rounded-full font-bold text-sm transition-all duration-300 ${activeTab === 'entity' ? 'bg-blue-900 text-white shadow-lg' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'}`}
                >
                    A Entidade
                </button>
                <button 
                    onClick={() => setActiveTab('board')}
                    className={`px-8 py-3 rounded-full font-bold text-sm transition-all duration-300 ${activeTab === 'board' ? 'bg-blue-900 text-white shadow-lg' : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'}`}
                >
                    Diretoria Executiva
                </button>
            </div>
        </div>

        {activeTab === 'entity' ? (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                {/* Main Entity Content */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
                    <div className="relative h-[500px] rounded-[2.5rem] overflow-hidden shadow-2xl shadow-blue-900/20 border-8 border-white group">
                        <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=800&q=80" alt="Sede CDL" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" />
                        <div className="absolute inset-0 bg-gradient-to-t from-blue-900 via-transparent to-transparent opacity-80"></div>
                        <div className="absolute bottom-0 left-0 p-10 w-full">
                            <span className="bg-yellow-400 text-blue-900 text-xs font-bold px-3 py-1 rounded-full uppercase mb-4 inline-block">Nossa Casa</span>
                            <h3 className="text-white font-bold text-3xl mb-2">Sede CDL Sorriso</h3>
                            <p className="text-blue-100 text-lg">Há 35 anos construindo histórias e fortalecendo o comércio.</p>
                        </div>
                    </div>
                    <div className="space-y-8">
                        <div>
                            <h3 className="text-3xl font-bold text-slate-800 mb-4">Nossa História</h3>
                            <p className="text-slate-600 leading-relaxed text-lg mb-4">
                                A Câmara de Dirigentes Lojistas de Sorriso (CDL Sorriso) é uma entidade civil, sem fins lucrativos, criada para defender, orientar e representar os interesses da classe lojista. Desde sua fundação, tem sido peça chave no desenvolvimento econômico da Capital do Agronegócio.
                            </p>
                            <button className="text-blue-600 font-bold flex items-center gap-2 hover:gap-3 transition-all">
                                Ler estatuto completo <ArrowRight className="w-4 h-4" />
                            </button>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-6">
                            <div className="p-6 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                                <span className="block text-4xl font-bold text-blue-600 mb-1">+1.5k</span>
                                <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Associados</span>
                            </div>
                            <div className="p-6 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
                                <span className="block text-4xl font-bold text-yellow-500 mb-1">35</span>
                                <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">Anos de História</span>
                            </div>
                        </div>
                    </div>
                </div>

                {/* MVV Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
                    <div className="bg-white p-10 rounded-[2rem] shadow-sm border border-slate-100 text-center group hover:border-blue-200 hover:-translate-y-2 transition-all duration-300">
                        <div className="w-20 h-20 mx-auto bg-blue-50 rounded-2xl flex items-center justify-center mb-8 text-blue-600 group-hover:scale-110 group-hover:rotate-3 transition-transform">
                            <Target className="w-10 h-10" />
                        </div>
                        <h3 className="text-2xl font-bold text-slate-800 mb-4">Missão</h3>
                        <p className="text-slate-500 leading-relaxed">
                            Representar e fortalecer a classe lojista, oferecendo soluções que contribuam para o desenvolvimento sustentável.
                        </p>
                    </div>
                    <div className="bg-white p-10 rounded-[2rem] shadow-sm border border-slate-100 text-center group hover:border-yellow-200 hover:-translate-y-2 transition-all duration-300 relative overflow-hidden">
                        <div className="w-20 h-20 mx-auto bg-yellow-50 rounded-2xl flex items-center justify-center mb-8 text-yellow-600 group-hover:scale-110 group-hover:-rotate-3 transition-transform relative z-10">
                            <Award className="w-10 h-10" />
                        </div>
                        <h3 className="text-2xl font-bold text-slate-800 mb-4 relative z-10">Visão</h3>
                        <p className="text-slate-500 leading-relaxed relative z-10">
                            Ser referência estadual como entidade representativa, reconhecida pela excelência na prestação de serviços.
                        </p>
                    </div>
                    <div className="bg-white p-10 rounded-[2rem] shadow-sm border border-slate-100 text-center group hover:border-red-200 hover:-translate-y-2 transition-all duration-300">
                        <div className="w-20 h-20 mx-auto bg-red-50 rounded-2xl flex items-center justify-center mb-8 text-red-500 group-hover:scale-110 group-hover:rotate-3 transition-transform">
                            <Heart className="w-10 h-10" />
                        </div>
                        <h3 className="text-2xl font-bold text-slate-800 mb-4">Valores</h3>
                        <p className="text-slate-500 leading-relaxed">
                            Ética, transparência, associativismo, inovação, responsabilidade social e comprometimento.
                        </p>
                    </div>
                </div>

                {/* Collaborators Section */}
                <div className="border-t border-slate-200 pt-16 relative">
                    <div className="flex justify-between items-end mb-10 px-4">
                        <div>
                            <h3 className="text-2xl font-bold text-slate-800">Nossa Equipe Técnica</h3>
                            <p className="text-slate-500 mt-1">O time operacional que faz a CDL acontecer.</p>
                        </div>
                        <div className="hidden md:flex gap-2 text-slate-400">
                             <span className="text-xs uppercase font-bold tracking-widest">Arraste para navegar</span>
                             <ArrowRight className="w-4 h-4" />
                        </div>
                    </div>
                    
                    <div className="relative w-full overflow-x-auto no-scrollbar pb-12 px-4 group/track">
                         <div className="flex gap-5 w-max mx-auto md:mx-0">
                            {COLLABORATORS.map((collab) => (
                                <PersonCard key={collab.id} person={collab} type="team" />
                            ))}
                         </div>
                    </div>
                </div>
            </div>
        ) : (
            <div className="animate-in fade-in slide-in-from-right-8 duration-500">
                 {/* Diretoria Section - CAROUSEL STYLE */}
                 <div className="mb-20">
                    <div className="flex justify-between items-end mb-8 px-4">
                        <div>
                            <h3 className="text-2xl font-bold text-slate-800">Diretoria Executiva</h3>
                            <p className="text-slate-500">
                                Líderes voluntários eleitos para conduzir a entidade.
                            </p>
                        </div>
                        <div className="hidden md:flex gap-2 text-slate-400">
                             <span className="text-xs uppercase font-bold tracking-widest">Arraste para navegar</span>
                             <ArrowRight className="w-4 h-4" />
                        </div>
                    </div>

                    <div className="relative w-full overflow-x-auto no-scrollbar pb-12 px-4 group/track">
                        <div className="flex gap-5 w-max mx-auto md:mx-0">
                            {BOARD_MEMBERS.map((member) => (
                                <PersonCard key={member.id} person={member} type="board" />
                            ))}
                        </div>
                    </div>
                 </div>

                {/* Ex-Presidents */}
                <div className="mt-8 max-w-5xl mx-auto bg-white rounded-3xl border border-slate-100 p-8 text-center shadow-sm">
                    <h4 className="text-slate-400 font-bold text-xs uppercase tracking-widest mb-8 flex items-center justify-center gap-4">
                        <span className="h-px w-12 bg-slate-200"></span>
                        Galeria de Ex-Presidentes
                        <span className="h-px w-12 bg-slate-200"></span>
                    </h4>
                    <div className="flex flex-wrap justify-center gap-3">
                        {['João Silva (2020-2022)', 'Maria Santos (2018-2020)', 'Pedro Alves (2016-2018)', 'Carlos Oliveira (2014-2016)', 'Roberto Mendes (2012-2014)'].map((name, i) => (
                             <span key={i} className="px-4 py-2 bg-slate-50 rounded-lg text-slate-600 text-xs font-bold border border-slate-100">
                                {name}
                             </span>
                        ))}
                    </div>
                </div>
            </div>
        )}
      </div>
    </section>
  );
};

export default Institutional;
