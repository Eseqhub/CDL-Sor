
import React, { useState } from 'react';
import { ArrowLeft, Check, Lock, QrCode, CreditCard, Calendar, MapPin, Clock, Users, Building, ShieldCheck, Info } from 'lucide-react';
import { Product } from '../types';

interface Props {
  product: Product;
  onBack: () => void;
}

const ProductLandingPage: React.FC<Props> = ({ product, onBack }) => {
  const [step, setStep] = useState(1); // 1: Details, 2: Checkout, 3: Success
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    role: '', 
    document: ''
  });

  const isWomenEvent = product.formType === 'women_event';
  const isGrowthEvent = product.formType === 'growth_event';

  return (
    <div className="min-h-screen bg-slate-50 font-sans animate-in slide-in-from-right">
      {/* Header Minimalista */}
      <header className="bg-white border-b border-slate-100 py-4 px-6 flex justify-between items-center sticky top-0 z-40 shadow-sm">
         <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-slate-800 font-bold text-sm">
            <ArrowLeft className="w-4 h-4" /> Cancelar
         </button>
         <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-green-600" />
            <span className="text-xs font-bold text-green-600 uppercase">Ambiente Seguro</span>
         </div>
      </header>

      {step === 1 && (
        <div className="container mx-auto px-4 py-10 max-w-6xl">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
                <div>
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-6 ${isWomenEvent ? 'bg-pink-100 text-pink-700' : 'bg-blue-100 text-blue-700'}`}>
                        {product.type === 'event' ? 'Evento Exclusivo' : 'Curso Presencial'}
                    </span>
                    <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 leading-tight">{product.title}</h1>
                    <p className="text-xl text-slate-600 mb-8 leading-relaxed">{product.description}</p>
                    
                    {/* Speakers Section */}
                    {product.speakers && (
                        <div className="mb-10">
                            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Palestrantes Confirmados</h3>
                            <div className="flex gap-4">
                                {product.speakers.map((speaker, i) => (
                                    <div key={i} className="flex items-center gap-3 bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                                        <img src={speaker.image} alt={speaker.name} className="w-12 h-12 rounded-full object-cover" />
                                        <div>
                                            <p className="font-bold text-slate-800 text-sm">{speaker.name}</p>
                                            <p className="text-xs text-slate-500">{speaker.role}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    <div className="space-y-4 mb-10 bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                         {product.date && (
                            <div className="flex items-center gap-3 text-slate-700 font-medium">
                                <Calendar className="w-5 h-5 text-blue-600" /> {product.date}
                            </div>
                         )}
                         {product.location && (
                            <div className="flex items-center gap-3 text-slate-700 font-medium">
                                <MapPin className="w-5 h-5 text-blue-600" /> {product.location}
                            </div>
                         )}
                         <div className="flex items-center gap-3 text-slate-700 font-medium">
                            <Users className="w-5 h-5 text-blue-600" /> Vagas Limitadas
                         </div>
                    </div>

                    <div className="mb-8">
                        <h3 className="font-bold text-slate-800 mb-4">O que está incluso:</h3>
                        <ul className="space-y-3">
                            {product.features.map((feat, i) => (
                                <li key={i} className="flex items-center gap-3 text-slate-600">
                                    <div className="p-0.5 bg-green-100 rounded-full text-green-600"><Check className="w-3 h-3" /></div>
                                    {feat}
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>

                <div className="relative sticky top-24">
                    <div className="bg-white p-8 rounded-3xl shadow-2xl border border-slate-100">
                        <img src={product.image} alt={product.title} className="rounded-2xl w-full h-48 object-cover mb-6" />
                        
                        <div className="flex justify-between items-end mb-6 border-b border-slate-100 pb-6">
                            <div>
                                <p className="text-slate-500 text-sm">Investimento</p>
                                <div className="flex items-baseline gap-2">
                                    <span className="text-4xl font-bold text-slate-900">R$ {product.price}</span>
                                    <span className="text-sm text-slate-400">/pessoa</span>
                                </div>
                            </div>
                            {isWomenEvent && (
                                <div className="text-right">
                                    <span className="bg-pink-50 text-pink-700 px-3 py-1 rounded-lg text-xs font-bold">Lote 1</span>
                                </div>
                            )}
                        </div>

                        {/* Rules Warning */}
                        {isWomenEvent && (
                            <div className="bg-orange-50 border border-orange-100 p-4 rounded-xl mb-6 text-sm text-orange-800 flex items-start gap-2">
                                <ShieldCheck className="w-5 h-5 flex-shrink-0 mt-0.5" />
                                <p><strong>Atenção:</strong> Evento destinado exclusivamente a proprietárias, esposas de proprietários ou cargos de gerência (comprovados).</p>
                            </div>
                        )}
                        
                         {isGrowthEvent && (
                            <div className="bg-blue-50 border border-blue-100 p-4 rounded-xl mb-6 text-sm text-blue-800 flex items-start gap-2">
                                <Info className="w-5 h-5 flex-shrink-0 mt-0.5" />
                                <p><strong>Nota:</strong> Recomendado para empresas com equipe comercial acima de 3 pessoas. Desconto para grupos via WhatsApp.</p>
                            </div>
                        )}

                        <button 
                            onClick={() => setStep(2)}
                            className="w-full bg-green-600 hover:bg-green-700 text-white text-lg font-bold py-4 px-8 rounded-xl shadow-lg shadow-green-600/30 transition-transform active:scale-95 flex items-center justify-center gap-2"
                        >
                            Garantir Minha Vaga <ArrowLeft className="w-5 h-5 rotate-180" />
                        </button>
                    </div>
                </div>
            </div>
        </div>
      )}

      {step === 2 && (
          <div className="container mx-auto px-4 py-10 max-w-2xl">
              <div className="bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden">
                  <div className="p-8 border-b border-slate-50 bg-slate-50/50">
                      <div className="flex justify-between items-center">
                        <div>
                            <h2 className="text-2xl font-bold text-slate-800">Finalizar Inscrição</h2>
                            <p className="text-slate-500 text-sm mt-1">{product.title}</p>
                        </div>
                        <div className="text-right">
                             <p className="text-xs text-slate-400 uppercase font-bold">Total a Pagar</p>
                             <p className="text-xl font-bold text-green-600">R$ {product.price},00</p>
                        </div>
                      </div>
                  </div>
                  
                  <div className="p-8 space-y-8">
                      {/* Section 1: Personal Data */}
                      <div className="space-y-4">
                          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 pb-2">Dados do Participante</h3>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <label className="block text-xs font-bold text-slate-600 mb-1">Nome Completo</label>
                                <input type="text" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 focus:ring-2 focus:ring-blue-500 outline-none transition-all" />
                              </div>
                              <div>
                                <label className="block text-xs font-bold text-slate-600 mb-1">CPF</label>
                                <input type="text" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 focus:ring-2 focus:ring-blue-500 outline-none transition-all" placeholder="000.000.000-00" />
                              </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <label className="block text-xs font-bold text-slate-600 mb-1">E-mail</label>
                                <input type="email" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 focus:ring-2 focus:ring-blue-500 outline-none transition-all" />
                              </div>
                              <div>
                                <label className="block text-xs font-bold text-slate-600 mb-1">WhatsApp</label>
                                <input type="tel" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 focus:ring-2 focus:ring-blue-500 outline-none transition-all" />
                              </div>
                          </div>

                          {/* CONDITIONAL FIELDS - LOGICA DE NEGÓCIO ESPECÍFICA */}
                          {(isWomenEvent || isGrowthEvent) && (
                              <div className="pt-4 animate-in fade-in">
                                  <div className={`p-4 rounded-xl border space-y-4 ${isWomenEvent ? 'bg-pink-50 border-pink-100' : 'bg-blue-50 border-blue-100'}`}>
                                      <h4 className={`text-sm font-bold flex items-center gap-2 ${isWomenEvent ? 'text-pink-800' : 'text-blue-800'}`}>
                                          <Building className="w-4 h-4" /> Dados da Empresa
                                      </h4>
                                      
                                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                          <div>
                                              <label className="block text-xs font-bold opacity-70 mb-1">Nome da Empresa</label>
                                              <input type="text" className="w-full bg-white border border-transparent rounded-xl p-3 focus:ring-2 focus:ring-blue-500 outline-none shadow-sm" />
                                          </div>
                                          <div>
                                              <label className="block text-xs font-bold opacity-70 mb-1">Seu Cargo / Função</label>
                                              <select className="w-full bg-white border border-transparent rounded-xl p-3 focus:ring-2 focus:ring-blue-500 outline-none text-slate-700 shadow-sm">
                                                  <option value="">Selecione...</option>
                                                  {isWomenEvent ? (
                                                      // OPÇÕES EXCLUSIVAS CHÁ DAS MULHERES
                                                      <>
                                                        <option value="owner">Proprietária / Sócia</option>
                                                        <option value="wife">Esposa de Proprietário</option>
                                                        <option value="manager">Gerente / Cargo de Confiança</option>
                                                      </>
                                                  ) : (
                                                      // OPÇÕES CONEXÃO GROWTH
                                                      <>
                                                        <option value="ceo">Diretor / CEO</option>
                                                        <option value="manager">Gerente Comercial</option>
                                                        <option value="sales">Vendedor / Consultor</option>
                                                      </>
                                                  )}
                                              </select>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          )}
                      </div>

                      {/* Section 2: Payment (Visual Mockup only - Backend Ready) */}
                      <div className="space-y-4 pt-4 border-t border-slate-50">
                          <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider border-b border-slate-100 pb-2">Pagamento Seguro</h3>
                          
                          <div className="bg-white border border-slate-300 rounded-xl p-4 shadow-sm focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-500 transition-all">
                              <div className="mb-3 border-b border-slate-100 pb-3">
                                  <label className="text-xs text-slate-400 font-bold uppercase block mb-1">Número do Cartão</label>
                                  <div className="flex items-center justify-between">
                                      <input type="text" placeholder="0000 0000 0000 0000" className="w-full outline-none text-slate-700 font-mono tracking-wide" />
                                      <div className="flex gap-1">
                                          <div className="w-8 h-5 bg-slate-200 rounded"></div>
                                          <div className="w-8 h-5 bg-slate-200 rounded"></div>
                                      </div>
                                  </div>
                              </div>
                              <div className="flex gap-4">
                                  <div className="flex-1 border-r border-slate-100 pr-4">
                                      <label className="text-xs text-slate-400 font-bold uppercase block mb-1">Validade</label>
                                      <input type="text" placeholder="MM/AA" className="w-full outline-none text-slate-700 font-mono" />
                                  </div>
                                  <div className="w-24">
                                      <label className="text-xs text-slate-400 font-bold uppercase block mb-1">CVC</label>
                                      <input type="text" placeholder="123" className="w-full outline-none text-slate-700 font-mono" />
                                  </div>
                              </div>
                          </div>
                          
                          <div className="flex items-center gap-2 text-xs text-slate-400 justify-center bg-slate-50 p-2 rounded-lg">
                              <Lock className="w-3 h-3" /> Seus dados são criptografados com segurança SSL de 256 bits.
                          </div>
                      </div>

                      <button 
                        onClick={() => setStep(3)}
                        className="w-full bg-green-600 text-white font-bold py-4 rounded-xl hover:bg-green-700 shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-2"
                      >
                          Pagar R$ {product.price},00
                      </button>
                  </div>
              </div>
          </div>
      )}

      {step === 3 && (
          <div className="container mx-auto px-4 py-20 max-w-md text-center animate-in zoom-in duration-300">
              <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-8 text-green-600 shadow-lg">
                  <Check className="w-12 h-12" />
              </div>
              <h2 className="text-3xl font-bold text-slate-800 mb-4">Inscrição Confirmada!</h2>
              <p className="text-slate-500 mb-8 leading-relaxed">
                  Parabéns! Você garantiu sua vaga no <strong>{product.title}</strong>. <br/>
                  Enviamos o comprovante e os detalhes de acesso para seu e-mail.
              </p>
              
              <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 mb-8 text-left">
                  <p className="text-xs font-bold text-slate-400 uppercase mb-2">Resumo do Pedido</p>
                  <div className="flex justify-between font-bold text-slate-700">
                      <span>1x Inscrição</span>
                      <span>R$ {product.price},00</span>
                  </div>
                  <div className="mt-4 pt-4 border-t border-slate-200 flex items-center gap-3">
                      <Calendar className="w-4 h-4 text-blue-500" />
                      <span className="text-sm text-slate-600">{product.date}</span>
                  </div>
              </div>

              <button onClick={onBack} className="w-full bg-slate-900 text-white px-8 py-3 rounded-xl font-bold hover:bg-slate-800 transition-colors">
                  Voltar ao Início
              </button>
          </div>
      )}
    </div>
  );
};

export default ProductLandingPage;
