import React from 'react';
import { Briefcase, Clock, MapPin, ArrowRight } from 'lucide-react';
import { JobOpportunity } from '../types';

interface Props {
  jobs: JobOpportunity[];
}

const JobBoard: React.FC<Props> = ({ jobs }) => {
  return (
    <section className="py-16 bg-white border-y border-slate-100">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-end mb-10">
            <div>
                <span className="text-yellow-500 font-bold tracking-wider text-sm uppercase mb-2 block">Banco de Talentos</span>
                <h2 className="text-3xl font-bold text-slate-900">Vagas em Destaque</h2>
            </div>
            <button className="hidden md:flex items-center gap-2 text-blue-600 font-bold hover:text-blue-800 transition-colors mt-4 md:mt-0">
                Ver todas as vagas <ArrowRight className="w-4 h-4" />
            </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {jobs.map((job) => (
                <div key={job.id} className="group border border-slate-200 rounded-2xl p-6 hover:border-blue-200 hover:bg-blue-50/30 transition-all duration-300 cursor-pointer">
                    <div className="flex justify-between items-start mb-4">
                        <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center text-blue-700">
                            <Briefcase className="w-5 h-5" />
                        </div>
                        <span className="bg-slate-100 text-slate-600 text-xs font-bold px-3 py-1 rounded-full">
                            {job.type}
                        </span>
                    </div>
                    
                    <h3 className="font-bold text-lg text-slate-800 group-hover:text-blue-700 mb-1">{job.title}</h3>
                    <p className="text-slate-500 text-sm mb-4">{job.company}</p>
                    
                    <div className="flex items-center gap-4 text-xs text-slate-400 border-t border-slate-100 pt-4">
                        <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" /> {job.location}
                        </span>
                        <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {job.date}
                        </span>
                    </div>
                </div>
            ))}
        </div>
        
        <button className="w-full md:hidden mt-8 py-3 border border-blue-200 text-blue-700 font-bold rounded-xl">
            Ver todas as vagas
        </button>

        <div className="mt-12 bg-gradient-to-r from-blue-900 to-blue-800 rounded-2xl p-8 md:p-12 text-center md:text-left flex flex-col md:flex-row items-center justify-between gap-8 shadow-xl">
            <div>
                <h3 className="text-2xl font-bold text-white mb-2">Sua empresa está contratando?</h3>
                <p className="text-blue-100">Cadastre suas vagas gratuitamente no portal da CDL Sorriso.</p>
            </div>
            <button className="bg-yellow-400 text-blue-900 hover:bg-yellow-300 font-bold py-3 px-8 rounded-xl shadow-lg shadow-yellow-400/20 transition-all whitespace-nowrap">
                Cadastrar Vaga
            </button>
        </div>
      </div>
    </section>
  );
};

export default JobBoard;