import React, { useState, useEffect } from 'react';
import { Menu, X, UserCircle, LogIn, FileText, Search } from 'lucide-react';
import CDLLogo from './CDLLogo';

interface Props {
    onNavigateLogin?: () => void;
}

const Header: React.FC<Props> = ({ onNavigateLogin }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed left-0 w-full z-40 transition-all duration-300 ${isScrolled ? 'top-14 bg-white/95 backdrop-blur-md shadow-md py-2' : 'top-14 bg-transparent py-4'}`}>
      <div className="container mx-auto px-4 flex justify-between items-center">
        {/* Logo Area */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo(0,0)}>
            <div className={`transition-all duration-300 ${isScrolled ? '' : 'drop-shadow-lg'}`}>
                <CDLLogo 
                    variant={isScrolled ? 'color' : 'white'} 
                    className="h-12 w-auto md:h-14" 
                />
            </div>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center gap-6">
          {['Início', 'Institucional', 'Serviços', 'Notícias', 'Galeria', 'Contato'].map((item) => (
            <a 
              key={item} 
              href={`#${item.toLowerCase()
                .replace('í', 'i')
                .replace('ç', 'c')
                .replace('õ', 'o')
                .replace('á', 'a')
                .replace(' ', '-')}`} 
              className={`text-sm font-bold hover:text-yellow-500 transition-colors relative after:content-[''] after:absolute after:w-0 after:h-0.5 after:bg-yellow-500 after:left-0 after:-bottom-1 after:transition-all hover:after:w-full ${isScrolled ? 'text-slate-700' : 'text-white'}`}
            >
              {item}
            </a>
          ))}
        </nav>

        {/* Actions */}
        <div className="hidden md:flex items-center gap-3">
           {/* Link Útil Rápido */}
           <a href="#" className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold border transition-all ${isScrolled ? 'border-blue-100 text-blue-600 hover:bg-blue-50' : 'border-white/20 text-white hover:bg-white/10'}`}>
              <FileText className="w-3 h-3" />
              2ª Via Boleto
           </a>

          <button 
            onClick={onNavigateLogin}
            className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold transition-all ${isScrolled ? 'text-blue-900 hover:bg-blue-50' : 'text-white hover:bg-white/10'}`}
          >
            <LogIn className="w-4 h-4" />
            Login
          </button>
          <button className="bg-yellow-400 hover:bg-yellow-300 text-blue-900 px-6 py-2.5 rounded-full text-sm font-bold transition-all shadow-lg shadow-yellow-400/20 hover:scale-105 active:scale-95 border-2 border-yellow-400">
            Seja Associado
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="lg:hidden p-2 focus:outline-none"
        >
          {isMobileMenuOpen ? 
            <X className={isScrolled ? 'text-slate-800' : 'text-white'} /> : 
            <Menu className={isScrolled ? 'text-slate-800' : 'text-white'} />
          }
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="absolute top-full left-0 w-full bg-white border-t border-slate-100 shadow-2xl lg:hidden flex flex-col py-4 animate-in slide-in-from-top-5 max-h-[80vh] overflow-y-auto">
          {['Início', 'Institucional', 'Serviços', 'Notícias', 'Galeria', 'Contato'].map((item) => (
            <a 
              key={item} 
              href={`#${item.toLowerCase().replace('í','i').replace('ç','c').replace(' ', '-')}`} 
              className="px-6 py-3 text-slate-600 hover:bg-blue-50 hover:text-blue-600 border-l-4 border-transparent hover:border-blue-600 transition-all font-medium"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {item}
            </a>
          ))}
           <div className="px-6 pt-6 border-t border-slate-100 mt-2 flex flex-col gap-3">
            <a href="#" className="w-full py-3 rounded-lg font-bold text-slate-600 bg-slate-50 flex items-center justify-center gap-2">
                <FileText className="w-4 h-4" />
                2ª Via Boleto
            </a>
            <a href="#" className="w-full py-3 rounded-lg font-bold text-slate-600 bg-slate-50 flex items-center justify-center gap-2">
                <Search className="w-4 h-4" />
                Consulta Pública
            </a>
            <button 
                onClick={() => { setIsMobileMenuOpen(false); if(onNavigateLogin) onNavigateLogin(); }}
                className="w-full py-3 rounded-lg font-bold text-blue-900 border border-blue-900/20 flex items-center justify-center gap-2"
            >
                <LogIn className="w-5 h-5" />
                Área do Cliente / Admin
            </button>
            <button className="w-full bg-yellow-500 text-blue-900 py-3 rounded-lg font-bold flex items-center justify-center gap-2 shadow-lg">
                <UserCircle className="w-5 h-5" />
                Quero me Associar
            </button>
           </div>
        </div>
      )}
    </header>
  );
};

export default Header;