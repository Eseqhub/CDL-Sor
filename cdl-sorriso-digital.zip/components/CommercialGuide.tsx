import React, { useState } from 'react';
import { Calendar, ChevronLeft, ChevronRight, Cake, Building, Flag, Star } from 'lucide-react';
import { CALENDAR_EVENTS } from '../constants';
import { EventType } from '../types';

const CommercialGuide: React.FC = () => {
  const [currentMonthIndex, setCurrentMonthIndex] = useState(new Date().getMonth());
  const months = [
    'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
  ];

  const nextMonth = () => setCurrentMonthIndex(prev => (prev + 1) % 12);
  const prevMonth = () => setCurrentMonthIndex(prev => (prev === 0 ? 11 : prev - 1));

  // Filter events for the current month (Assuming format DD/MM)
  const currentEvents = CALENDAR_EVENTS.filter(event => {
    const eventMonth = parseInt(event.date.split('/')[1]) - 1;
    return eventMonth === currentMonthIndex;
  }).sort((a, b) => parseInt(a.date.split('/')[0]) - parseInt(b.date.split('/')[0]));

  const getEventIcon = (type: EventType) => {
    switch (type) {
      case 'holiday': return <Flag className="w-5 h-5 text-red-500" />;
      case 'business_anniversary': return <Building className="w-5 h-5 text-yellow-500" />;
      case 'birthday': return <Cake className="w-5 h-5 text-green-500" />;
      default: return <Star className="w-5 h-5 text-blue-500" />;
    }
  };

  const getEventLabel = (type: EventType) => {
    switch (type) {
      case 'holiday': return 'Feriado / Data Oficial';
      case 'business_anniversary': return 'Aniversário de Empresa';
      case 'birthday': return 'Aniversariante CDL';
      default: return 'Data Comemorativa';
    }
  };

  const getEventColor = (type: EventType) => {
    switch (type) {
      case 'holiday': return 'border-l-red-500 bg-red-50/50';
      case 'business_anniversary': return 'border-l-yellow-500 bg-yellow-50/50';
      case 'birthday': return 'border-l-green-500 bg-green-50/50';
      default: return 'border-l-blue-500 bg-blue-50/50';
    }
  };

  return (
    <section className="py-20 bg-white border-b border-slate-100" id="guia-comercial">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
            <div>
                <span className="text-blue-600 font-bold tracking-wider text-sm uppercase mb-2 block">Agenda Institucional</span>
                <h2 className="text-3xl md:text-4xl font-bold text-slate-800">Calendário Permanente</h2>
                <p className="text-slate-500 mt-2 max-w-xl">
                    Acompanhe feriados, datas comemorativas, aniversários de empresas associadas e da nossa equipe diretora.
                </p>
            </div>
            
            {/* Month Navigation */}
            <div className="flex items-center gap-4 mt-6 md:mt-0 bg-slate-50 p-2 rounded-2xl border border-slate-100">
                <button onClick={prevMonth} className="p-3 hover:bg-white rounded-xl shadow-sm transition-all hover:text-blue-600">
                    <ChevronLeft className="w-5 h-5" />
                </button>
                <div className="min-w-[140px] text-center">
                    <span className="block text-xs text-slate-400 font-bold uppercase tracking-widest">Mês de</span>
                    <span className="text-xl font-bold text-slate-800">{months[currentMonthIndex]}</span>
                </div>
                <button onClick={nextMonth} className="p-3 hover:bg-white rounded-xl shadow-sm transition-all hover:text-blue-600">
                    <ChevronRight className="w-5 h-5" />
                </button>
            </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-4 mb-8 text-xs font-medium text-slate-500">
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-red-500"></div>Feriados</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-yellow-500"></div>Empresas</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-green-500"></div>Aniversariantes</div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 rounded-full bg-blue-500"></div>Comemorativo</div>
        </div>

        {/* Events Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {currentEvents.length > 0 ? (
                currentEvents.map((event) => (
                    <div key={event.id} className={`relative p-6 rounded-2xl border-l-4 border hover:shadow-lg transition-all duration-300 group ${getEventColor(event.type)} border-slate-100`}>
                        <div className="flex justify-between items-start mb-4">
                            <div className="flex items-center gap-3">
                                <div className="w-12 h-12 rounded-xl bg-white shadow-sm flex flex-col items-center justify-center border border-slate-100">
                                    <span className="text-xs font-bold text-slate-400 uppercase">{months[currentMonthIndex].substring(0,3)}</span>
                                    <span className="text-lg font-bold text-slate-800 leading-none">{event.date.split('/')[0]}</span>
                                </div>
                                <div>
                                    <div className="flex items-center gap-1.5 mb-1">
                                        {getEventIcon(event.type)}
                                        <span className="text-[10px] font-bold uppercase tracking-wider opacity-70">{getEventLabel(event.type)}</span>
                                    </div>
                                    <h3 className="font-bold text-slate-800 text-lg leading-tight group-hover:text-blue-700 transition-colors">{event.title}</h3>
                                </div>
                            </div>
                        </div>
                        {event.details && (
                            <div className="mt-3 pt-3 border-t border-slate-200/50 flex items-center gap-2 text-sm text-slate-600">
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
                                {event.details}
                            </div>
                        )}
                        {event.type === 'business_anniversary' && (
                            <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                                <span className="text-[10px] bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full font-bold">Parabéns!</span>
                            </div>
                        )}
                    </div>
                ))
            ) : (
                <div className="col-span-full py-16 text-center bg-slate-50 rounded-3xl border border-slate-200 border-dashed">
                    <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                    <h3 className="text-xl font-bold text-slate-600">Sem eventos cadastrados</h3>
                    <p className="text-slate-400">Nenhum evento especial encontrado para {months[currentMonthIndex]}.</p>
                </div>
            )}
        </div>
      </div>
    </section>
  );
};

export default CommercialGuide;