import React from 'react';

interface Props {
  variant?: 'color' | 'white';
  className?: string;
}

export const CDLLogo: React.FC<Props> = ({ variant = 'color', className = "h-12 w-auto" }) => {
  // SE VOCÊ TIVER O ARQUIVO DE IMAGEM (PNG/JPG):
  // 1. Salve o arquivo na pasta public com o nome 'logo-cdl.png'
  // 2. Descomente a linha abaixo e comente o restante do SVG:
  // return <img src="/logo-cdl.png" alt="CDL Sorriso" className={className} />;

  const isWhite = variant === 'white';
  
  // CORES OFICIAIS DA IDENTIDADE VISUAL
  const colors = {
    blue: isWhite ? '#FFFFFF' : '#003087', // Pantone 281 C approx
    green: isWhite ? '#FFFFFF' : '#009B3A', // Pantone 347 C approx
    yellow: isWhite ? '#FFFFFF' : '#FFCC00', // Pantone 123 C approx
    textBlue: isWhite ? '#FFFFFF' : '#003087',
    textGreen: isWhite ? '#FFFFFF' : '#009B3A'
  };

  // AQUI VOCÊ PODE COLAR O SEU SVG ORIGINAL SE QUISER VETORIAL
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 300 100" 
      className={className}
      aria-label="CDL Sorriso Logo"
    >
      {/* Símbolo da Vela / Nau (Identidade Visual CDL) */}
      <g transform="translate(10, 10) scale(0.8)">
        <path 
          d="M0,0 C0,0 20,5 40,5 C60,5 80,0 80,0 L80,60 C80,60 60,75 30,80 C10,83 0,85 0,85 L0,0 Z" 
          fill={colors.blue} 
        />
        <path 
          d="M30,80 C45,78 60,70 70,60 L80,60 C80,60 65,80 35,85 L30,80 Z" 
          fill={colors.yellow} 
        />
        <path 
          d="M0,85 C15,84 35,85 35,85 C55,82 75,70 85,60 L85,85 C85,85 50,95 0,90 L0,85 Z" 
          fill={colors.green} 
        />
      </g>

      {/* Tipografia Oficial */}
      <text 
        x="90" 
        y="65" 
        fontFamily="Arial, sans-serif" 
        fontWeight="900" 
        fontSize="60" 
        fill={colors.textBlue}
        style={{ letterSpacing: '-2px', fontStyle: 'italic' }}
      >
        CDL
      </text>

      <text 
        x="92" 
        y="90" 
        fontFamily="Arial, sans-serif" 
        fontWeight="bold" 
        fontSize="24" 
        fill={colors.textGreen}
        style={{ letterSpacing: '1px' }}
      >
        Sorriso
      </text>
    </svg>
  );
};

export default CDLLogo;