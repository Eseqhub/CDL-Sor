import React, { useState } from 'react';
import { Lock, User, ArrowRight } from 'lucide-react';
import CDLLogo from '../CDLLogo';

interface Props {
    onLogin: () => void;
    onBack: () => void;
}

const AdminLogin: React.FC<Props> = ({ onLogin, onBack }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        // Simulate API call
        setTimeout(() => {
            setIsLoading(false);
            onLogin();
        }, 1500);
    };

    return (
        <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 relative overflow-hidden">
            {/* Background Effects */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0">
                <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-600/20 rounded-full blur-[120px] animate-pulse"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-yellow-500/10 rounded-full blur-[120px] animate-pulse delay-1000"></div>
            </div>

            <div className="bg-white w-full max-w-md p-8 rounded-3xl shadow-2xl z-10 relative animate-in fade-in zoom-in-95 duration-500">
                <div className="text-center mb-8">
                    <div className="flex justify-center mb-6">
                        <CDLLogo variant="color" className="h-16 w-auto" />
                    </div>
                    <h2 className="text-2xl font-bold text-slate-800">Painel Administrativo</h2>
                    <p className="text-slate-500 text-sm mt-1">Gestão Digital CDL Sorriso</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-600 uppercase ml-1">Usuário</label>
                        <div className="relative">
                            <User className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
                            <input 
                                type="text" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-12 pr-4 text-slate-700 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
                                placeholder="admin@cdlsorriso.com.br"
                                required
                            />
                        </div>
                    </div>

                    <div className="space-y-1">
                        <label className="text-xs font-bold text-slate-600 uppercase ml-1">Senha</label>
                        <div className="relative">
                            <Lock className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
                            <input 
                                type="password" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full bg-slate-50 border border-slate-200 rounded-xl py-3 pl-12 pr-4 text-slate-700 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
                                placeholder="••••••••"
                                required
                            />
                        </div>
                    </div>

                    <button 
                        type="submit" 
                        disabled={isLoading}
                        className="w-full bg-blue-900 text-white font-bold py-4 rounded-xl hover:bg-blue-800 transition-all shadow-lg shadow-blue-900/30 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed mt-4"
                    >
                        {isLoading ? (
                            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        ) : (
                            <>
                                Entrar no Sistema <ArrowRight className="w-4 h-4" />
                            </>
                        )}
                    </button>
                </form>

                <button 
                    onClick={onBack}
                    className="w-full mt-6 text-sm text-slate-400 hover:text-slate-600 transition-colors font-medium"
                >
                    ← Voltar para o site
                </button>
            </div>
        </div>
    );
};

export default AdminLogin;