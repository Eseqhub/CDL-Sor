
import React from 'react';
import { Bold, Italic, List, Link as LinkIcon, AlignLeft, AlignCenter, AlignRight, Type } from 'lucide-react';

interface Props {
  value: string;
  onChange: (value: string) => void;
  label?: string;
}

const RichTextEditor: React.FC<Props> = ({ value, onChange, label }) => {
  
  const handleFormat = (command: string, value?: string) => {
    document.execCommand(command, false, value);
  };

  return (
    <div className="border border-slate-200 rounded-xl overflow-hidden bg-white flex flex-col h-[400px]">
      {label && <div className="px-4 py-2 bg-slate-50 border-b border-slate-100 text-xs font-bold text-slate-500 uppercase">{label}</div>}
      
      {/* Toolbar */}
      <div className="flex flex-wrap gap-1 p-2 border-b border-slate-100 bg-slate-50">
        <ToolButton icon={Bold} onClick={() => handleFormat('bold')} title="Negrito" />
        <ToolButton icon={Italic} onClick={() => handleFormat('italic')} title="Itálico" />
        <div className="w-px h-6 bg-slate-300 mx-1 self-center"></div>
        <ToolButton icon={AlignLeft} onClick={() => handleFormat('justifyLeft')} title="Alinhar Esquerda" />
        <ToolButton icon={AlignCenter} onClick={() => handleFormat('justifyCenter')} title="Centralizar" />
        <ToolButton icon={AlignRight} onClick={() => handleFormat('justifyRight')} title="Alinhar Direita" />
        <div className="w-px h-6 bg-slate-300 mx-1 self-center"></div>
        <ToolButton icon={List} onClick={() => handleFormat('insertUnorderedList')} title="Lista" />
        <ToolButton icon={LinkIcon} onClick={() => {
            const url = prompt('Digite a URL:');
            if(url) handleFormat('createLink', url);
        }} title="Link" />
        <div className="w-px h-6 bg-slate-300 mx-1 self-center"></div>
        <ToolButton icon={Type} onClick={() => handleFormat('formatBlock', 'H3')} title="Título" />
      </div>

      {/* Editable Area */}
      <div 
        className="flex-1 p-4 outline-none overflow-y-auto prose prose-sm max-w-none"
        contentEditable
        onInput={(e) => onChange(e.currentTarget.innerHTML)}
        dangerouslySetInnerHTML={{ __html: value }}
        style={{ minHeight: '200px' }}
      ></div>
      
      <div className="px-4 py-2 bg-slate-50 border-t border-slate-100 text-[10px] text-slate-400 flex justify-between">
         <span>Editor HTML Visual</span>
         <span>{value.length} caracteres</span>
      </div>
    </div>
  );
};

const ToolButton: React.FC<{ icon: React.ElementType, onClick: () => void, title: string }> = ({ icon: Icon, onClick, title }) => (
    <button 
        type="button"
        onClick={onClick}
        title={title}
        className="p-2 rounded hover:bg-slate-200 text-slate-600 hover:text-blue-600 transition-colors"
    >
        <Icon className="w-4 h-4" />
    </button>
);

export default RichTextEditor;
