
import React, { useState, useEffect } from 'react';
import { 
    LayoutGrid, Users, FileText, Settings, LogOut, Plus, 
    TrendingUp, Image as ImageIcon, MapPin, ShoppingBag, 
    Calendar, Trash2, Edit2, Percent, CheckCircle2, X, Save, UploadCloud, FileImage 
} from 'lucide-react';
import { BoardMember, TeamMember, Partner, GalleryItem, NewsPost, Product } from '../../types';
import RichTextEditor from './RichTextEditor';
import { 
    uploadImage, 
    fetchItems, 
    createItem, 
    updateItem, 
    deleteItem,
    getDiretoria,
    getColaboradores,
    getParceiros,
    getGaleria,
    getNoticias,
    getProdutos
} from '../../services/dataService';

// Fallback constants
import { BOARD_MEMBERS, COLLABORATORS, PARTNERS_DATA, GALLERY_IMAGES, NEWS_DATA, PRODUCTS_DATA } from '../../constants';

interface Props {
    onLogout: () => void;
}

type AdminTab = 'dashboard' | 'companies' | 'content' | 'institutional' | 'partners' | 'calendar' | 'indicators' | 'products' | 'gallery';
type ItemType = 'board_members' | 'team_members' | 'partners' | 'gallery' | 'news' | 'products'; // Nomes das tabelas no Supabase

const AdminDashboard: React.FC<Props> = ({ onLogout }) => {
    const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
    const [notification, setNotification] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);

    // --- STATE MANAGEMENT ---
    const [boardList, setBoardList] = useState<BoardMember[]>(BOARD_MEMBERS);
    const [collabList, setCollabList] = useState<TeamMember[]>(COLLABORATORS);
    const [partnerList, setPartnerList] = useState<Partner[]>(PARTNERS_DATA);
    const [galleryList, setGalleryList] = useState<GalleryItem[]>(GALLERY_IMAGES);
    const [newsList, setNewsList] = useState<NewsPost[]>(NEWS_DATA);
    const [productList, setProductList] = useState<Product[]>(PRODUCTS_DATA);
    
    // Categorias de Convênios Dinâmicas
    const [partnerCategories, setPartnerCategories] = useState<string[]>([
        'Saúde', 'Educação', 'Alimentação', 'Lazer', 'Serviços', 'Automotivo', 'Pet', 'Seguros', 'Varejo'
    ]);

    // Modal State
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<any | null>(null);
    const [itemType, setItemType] = useState<ItemType | null>(null);
    
    // File Upload State inside Modal
    const [previewImage, setPreviewImage] = useState<string | null>(null);
    const [fileToUpload, setFileToUpload] = useState<File | null>(null);
    const [galleryFiles, setGalleryFiles] = useState<File[]>([]);

    // --- INITIAL DATA FETCH ---
    useEffect(() => {
        const loadData = async () => {
            setIsLoading(true);
            setBoardList(await getDiretoria());
            setCollabList(await getColaboradores());
            setPartnerList(await getParceiros());
            setGalleryList(await getGaleria());
            setNewsList(await getNoticias());
            setProductList(await getProdutos());
            setIsLoading(false);
        };
        loadData();
    }, []);

    const showNotification = (msg: string) => {
        setNotification(msg);
        setTimeout(() => setNotification(null), 3000);
    };

    // --- ACTIONS ---

    const handleDelete = async (id: string, table: ItemType) => {
        if (!window.confirm("Tem certeza que deseja excluir este item? Essa ação é irreversível.")) return;
        setIsLoading(true);
        try {
            await deleteItem(table, id);
            
            // Refresh local state
            if (table === 'board_members') setBoardList(prev => prev.filter(i => i.id !== id));
            if (table === 'team_members') setCollabList(prev => prev.filter(i => i.id !== id));
            if (table === 'partners') setPartnerList(prev => prev.filter(i => i.id !== id));
            if (table === 'gallery') setGalleryList(prev => prev.filter(i => i.id !== id));
            if (table === 'news') setNewsList(prev => prev.filter(i => i.id !== id));
            if (table === 'products') setProductList(prev => prev.filter(i => i.id !== id));
            
            showNotification("Item excluído com sucesso!");
        } catch (error) {
            console.error(error);
            showNotification("Erro ao excluir item.");
        } finally {
            setIsLoading(false);
        }
    };

    const handleEdit = (item: any, table: ItemType) => {
        setEditingItem({ ...item });
        setItemType(table);
        setPreviewImage(item.image || null);
        setFileToUpload(null);
        setGalleryFiles([]);
        setIsModalOpen(true);
    };

    const handleAddNew = (table: ItemType) => {
        setEditingItem({});
        setItemType(table);
        setPreviewImage(null);
        setFileToUpload(null);
        setGalleryFiles([]);
        setIsModalOpen(true);
    };

    const handleAddCategory = () => {
        const newCat = window.prompt("Digite o nome da nova categoria:");
        if (newCat && !partnerCategories.includes(newCat)) {
            setPartnerCategories([...partnerCategories, newCat]);
            setEditingItem((prev: any) => ({ ...prev, category: newCat }));
            showNotification(`Categoria "${newCat}" adicionada!`);
        }
    };

    // --- FILE UPLOAD HANDLER ---
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, isMultiple: boolean = false) => {
        if (e.target.files && e.target.files.length > 0) {
            const file = e.target.files[0];
            
            if (isMultiple) {
                const files = Array.from(e.target.files);
                setGalleryFiles(files);
                setEditingItem((prev: any) => ({ ...prev, count: files.length }));
                // Preview first
                const reader = new FileReader();
                reader.onloadend = () => setPreviewImage(reader.result as string);
                reader.readAsDataURL(file);
            } else {
                setFileToUpload(file);
                const reader = new FileReader();
                reader.onloadend = () => setPreviewImage(reader.result as string);
                reader.readAsDataURL(file);
            }
        }
    };

    // --- SAVE TO SUPABASE ---
    const handleSave = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!editingItem || !itemType) return;
        setIsLoading(true);

        try {
            let finalImageUrl = editingItem.image;

            // 1. Upload Image if new file selected
            if (fileToUpload) {
                const url = await uploadImage(fileToUpload, itemType);
                if (url) finalImageUrl = url;
            }

            // Prepare Data
            const itemData = { 
                ...editingItem, 
                image: finalImageUrl 
            };

            // 2. Insert or Update in Supabase
            let savedItem;
            if (editingItem.id) {
                savedItem = await updateItem(itemType, editingItem.id, itemData);
            } else {
                savedItem = await createItem(itemType, itemData);
            }

            // 3. Update Local State (Optimistic or with response)
            // Note: Since Supabase might return different ID formats or structure, 
            // ideally we would reload, but here we merge.
            const newItem = savedItem || { ...itemData, id: Date.now().toString() }; // Fallback id if mock

            const updateList = (list: any[], setList: Function) => {
                if (editingItem.id) {
                    setList(list.map(i => i.id === newItem.id ? newItem : i));
                } else {
                    setList([newItem, ...list]);
                }
            };

            if (itemType === 'board_members') updateList(boardList, setBoardList);
            if (itemType === 'team_members') updateList(collabList, setCollabList);
            if (itemType === 'partners') updateList(partnerList, setPartnerList);
            if (itemType === 'gallery') updateList(galleryList, setGalleryList);
            if (itemType === 'news') updateList(newsList, setNewsList);
            if (itemType === 'products') updateList(productList, setProductList);

            setIsModalOpen(false);
            setEditingItem(null);
            showNotification("Dados salvos com sucesso!");

        } catch (error) {
            console.error("Erro ao salvar:", error);
            showNotification("Erro ao salvar dados. Verifique a conexão.");
        } finally {
            setIsLoading(false);
        }
    };

    // --- RENDERERS ---

    const renderInstitutionalManager = () => (
        <div className="animate-in fade-in duration-500">
             <header className="flex justify-between items-center mb-8">
                <div>
                    <h2 className="text-2xl font-bold text-slate-800">Gestão Institucional</h2>
                    <p className="text-slate-500 text-sm">Gerencie os membros da diretoria e colaboradores.</p>
                </div>
                <button 
                    onClick={() => handleAddNew('board_members')}
                    className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-blue-700 transition-colors"
                >
                    <Plus className="w-4 h-4" /> Adicionar Diretor
                </button>
            </header>

            {/* Board Section */}
            <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden mb-8">
                <div className="p-6 border-b border-slate-100 bg-slate-50/50">
                    <h3 className="font-bold text-slate-800">Diretoria Executiva</h3>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-bold">
                            <tr>
                                <th className="px-6 py-4">Foto</th>
                                <th className="px-6 py-4">Nome</th>
                                <th className="px-6 py-4">Cargo</th>
                                <th className="px-6 py-4 text-right">Ações</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {boardList.map((member) => (
                                <tr key={member.id} className="hover:bg-slate-50">
                                    <td className="px-6 py-3">
                                        <img src={member.image} alt="" className="w-10 h-10 rounded-full object-cover border border-slate-200" />
                                    </td>
                                    <td className="px-6 py-3 font-bold text-slate-700">{member.name}</td>
                                    <td className="px-6 py-3 text-sm text-slate-500">{member.role}</td>
                                    <td className="px-6 py-3 text-right">
                                        <div className="flex justify-end gap-2">
                                            <button onClick={() => handleEdit(member, 'board_members')} className="p-2 hover:bg-blue-50 text-blue-600 rounded-lg transition-colors"><Edit2 className="w-4 h-4" /></button>
                                            <button onClick={() => handleDelete(member.id, 'board_members')} className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
            
            <header className="flex justify-between items-center mb-4 mt-12">
                <h3 className="font-bold text-slate-800 text-lg">Equipe Técnica (Colaboradores)</h3>
                <button 
                    onClick={() => handleAddNew('team_members')}
                    className="flex items-center gap-2 bg-slate-200 text-slate-700 px-4 py-2 rounded-lg text-sm font-bold hover:bg-slate-300 transition-colors"
                >
                    <Plus className="w-4 h-4" /> Adicionar Colaborador
                </button>
            </header>
             <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden mb-8">
                 <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-bold">
                            <tr>
                                <th className="px-6 py-4">Foto</th>
                                <th className="px-6 py-4">Nome</th>
                                <th className="px-6 py-4">Departamento</th>
                                <th className="px-6 py-4 text-right">Ações</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                            {collabList.map((collab) => (
                                <tr key={collab.id} className="hover:bg-slate-50">
                                    <td className="px-6 py-3">
                                        <img src={collab.image} alt="" className="w-10 h-10 rounded-full object-cover border border-slate-200" />
                                    </td>
                                    <td className="px-6 py-3 font-bold text-slate-700">{collab.name}</td>
                                    <td className="px-6 py-3 text-sm text-slate-500">{collab.department}</td>
                                    <td className="px-6 py-3 text-right">
                                        <div className="flex justify-end gap-2">
                                            <button onClick={() => handleEdit(collab, 'team_members')} className="p-2 hover:bg-blue-50 text-blue-600 rounded-lg transition-colors"><Edit2 className="w-4 h-4" /></button>
                                            <button onClick={() => handleDelete(collab.id, 'team_members')} className="p-2 hover:bg-red-50 text-red-600 rounded-lg transition-colors"><Trash2 className="w-4 h-4" /></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
             </div>
        </div>
    );

    const renderNewsManager = () => (
        <div className="animate-in fade-in duration-500">
             <header className="flex justify-between items-center mb-8">
                <div>
                    <h2 className="text-2xl font-bold text-slate-800">Notícias & Blog</h2>
                    <p className="text-slate-500 text-sm">Publique novidades e comunicados oficiais.</p>
                </div>
                <button 
                    onClick={() => handleAddNew('news')}
                    className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-blue-700 transition-colors"
                >
                    <Plus className="w-4 h-4" /> Nova Notícia
                </button>
            </header>

            <div className="grid grid-cols-1 gap-4">
                {newsList.map(news => (
                    <div key={news.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex gap-6 hover:shadow-md transition-shadow">
                        <img src={news.image} alt="" className="w-32 h-24 rounded-lg object-cover bg-slate-100 flex-shrink-0" />
                        <div className="flex-1">
                            <div className="flex justify-between items-start">
                                <span className="bg-blue-50 text-blue-600 text-[10px] font-bold px-2 py-1 rounded-md uppercase mb-2 inline-block">{news.category}</span>
                                <span className="text-xs text-slate-400">{news.date}</span>
                            </div>
                            <h3 className="text-lg font-bold text-slate-800 mb-2">{news.title}</h3>
                            <p className="text-sm text-slate-500 line-clamp-2">{news.excerpt}</p>
                        </div>
                        <div className="flex flex-col justify-center gap-2 border-l border-slate-100 pl-4">
                            <button onClick={() => handleEdit(news, 'news')} className="p-2 hover:bg-blue-50 text-blue-600 rounded-lg"><Edit2 className="w-4 h-4" /></button>
                            <button onClick={() => handleDelete(news.id, 'news')} className="p-2 hover:bg-red-50 text-red-600 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );

    const renderPartnersManager = () => (
        <div className="animate-in fade-in duration-500">
             <header className="flex justify-between items-center mb-8">
                <div>
                    <h2 className="text-2xl font-bold text-slate-800">Clube de Vantagens</h2>
                    <p className="text-slate-500 text-sm">Gerencie os convênios e descontos oferecidos.</p>
                </div>
                <button 
                    onClick={() => handleAddNew('partners')}
                    className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-blue-700 transition-colors"
                >
                    <Plus className="w-4 h-4" /> Novo Parceiro
                </button>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {partnerList.map(partner => (
                    <div key={partner.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-start gap-4 group hover:border-blue-200 transition-all">
                        <img src={partner.image} className="w-16 h-16 rounded-lg object-cover bg-slate-100" alt="" />
                        <div className="flex-1 min-w-0">
                            <h4 className="font-bold text-slate-800 truncate">{partner.name}</h4>
                            <p className="text-xs text-slate-500 mb-2">{partner.category}</p>
                            <span className="inline-block bg-yellow-100 text-yellow-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                                {partner.discount}
                            </span>
                        </div>
                        <div className="flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => handleEdit(partner, 'partners')} className="p-1.5 hover:bg-blue-50 text-blue-600 rounded-lg"><Edit2 className="w-4 h-4" /></button>
                            <button onClick={() => handleDelete(partner.id, 'partners')} className="p-1.5 hover:bg-red-50 text-red-600 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );

    const renderGalleryManager = () => (
        <div className="animate-in fade-in duration-500">
             <header className="flex justify-between items-center mb-8">
                <div>
                    <h2 className="text-2xl font-bold text-slate-800">Galeria de Fotos</h2>
                    <p className="text-slate-500 text-sm">Gerencie os álbuns de eventos sociais.</p>
                </div>
                <button 
                    onClick={() => handleAddNew('gallery')}
                    className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-blue-700 transition-colors"
                >
                    <Plus className="w-4 h-4" /> Novo Álbum
                </button>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {galleryList.map(item => (
                    <div key={item.id} className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden group">
                        <div className="h-40 relative">
                             <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                             <div className="absolute top-2 right-2 flex gap-1">
                                <button onClick={() => handleEdit(item, 'gallery')} className="p-2 bg-white/90 rounded-full hover:text-blue-600"><Edit2 className="w-3 h-3" /></button>
                                <button onClick={() => handleDelete(item.id, 'gallery')} className="p-2 bg-white/90 rounded-full hover:text-red-600"><Trash2 className="w-3 h-3" /></button>
                             </div>
                        </div>
                        <div className="p-4">
                            <h4 className="font-bold text-slate-800 text-sm mb-1 truncate">{item.title}</h4>
                            <div className="flex justify-between text-xs text-slate-500">
                                <span>{item.date}</span>
                                <span>{item.count} fotos</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );

    // --- MODAL COMPONENT ---
    const EditModal = () => {
        if (!isModalOpen || !editingItem) return null;

        return (
            <div className="fixed inset-0 z-[60] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in overflow-y-auto">
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden animate-in zoom-in-95 my-auto">
                    <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                        <h3 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                             {itemType === 'news' && <FileText className="w-5 h-5 text-blue-600" />}
                             {itemType === 'gallery' && <ImageIcon className="w-5 h-5 text-blue-600" />}
                             {itemType === 'partners' && <Percent className="w-5 h-5 text-blue-600" />}
                            {editingItem.id ? 'Editar Registro' : 'Novo Cadastro'}
                        </h3>
                        <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                            <X className="w-5 h-5" />
                        </button>
                    </div>
                    
                    <form onSubmit={handleSave} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto custom-scrollbar">
                        
                        {/* UPLOAD AREA (Universal) */}
                        <div className="space-y-2">
                            <label className="block text-xs font-bold text-slate-500 uppercase">Imagem Principal / Capa</label>
                            <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 flex flex-col items-center justify-center bg-slate-50 hover:bg-slate-100 transition-colors relative cursor-pointer group">
                                <input 
                                    type="file" 
                                    accept="image/*" 
                                    className="absolute inset-0 opacity-0 cursor-pointer z-10"
                                    onChange={(e) => handleFileChange(e, false)}
                                />
                                {previewImage ? (
                                    <div className="relative w-full h-48">
                                        <img src={previewImage} className="w-full h-full object-contain rounded-lg" alt="Preview" />
                                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-lg">
                                            <span className="text-white font-bold text-sm flex items-center gap-2"><UploadCloud className="w-4 h-4" /> Alterar Foto</span>
                                        </div>
                                    </div>
                                ) : (
                                    <>
                                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-3">
                                            <UploadCloud className="w-6 h-6 text-blue-600" />
                                        </div>
                                        <p className="text-sm font-bold text-slate-600">Clique ou arraste para enviar</p>
                                        <p className="text-xs text-slate-400">JPG, PNG ou WEBP (Max 5MB)</p>
                                    </>
                                )}
                            </div>
                        </div>

                        {/* CAMPOS COMUNS (Nome/Título) */}
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1">
                                {itemType === 'news' ? 'Título da Notícia' : (itemType === 'gallery' ? 'Nome do Evento' : 'Nome')}
                            </label>
                            <input 
                                type="text" 
                                className="w-full border border-slate-200 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 outline-none text-slate-700 font-bold"
                                value={editingItem.name || editingItem.title || ''}
                                onChange={e => setEditingItem({...editingItem, name: e.target.value, title: e.target.value})}
                                required
                            />
                        </div>

                        {/* NEWS SPECIFIC: RICH TEXT EDITOR */}
                        {itemType === 'news' && (
                            <>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Categoria</label>
                                    <select 
                                        className="w-full border border-slate-200 rounded-lg p-3 bg-white"
                                        value={editingItem.category || ''}
                                        onChange={e => setEditingItem({...editingItem, category: e.target.value})}
                                    >
                                        <option value="Notícias">Notícias</option>
                                        <option value="Eventos">Eventos</option>
                                        <option value="Capacitação">Capacitação</option>
                                        <option value="Comunicado">Comunicado</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Resumo (Excerpt)</label>
                                    <textarea 
                                        className="w-full border border-slate-200 rounded-lg p-3 h-20 focus:ring-2 focus:ring-blue-500 outline-none"
                                        value={editingItem.excerpt || ''}
                                        onChange={e => setEditingItem({...editingItem, excerpt: e.target.value})}
                                    ></textarea>
                                </div>
                                <div className="h-full">
                                    <RichTextEditor 
                                        label="Conteúdo Completo"
                                        value={editingItem.content || ''} 
                                        onChange={(val) => setEditingItem({...editingItem, content: val})} 
                                    />
                                </div>
                            </>
                        )}

                        {/* GALLERY SPECIFIC: MULTIPLE UPLOAD */}
                        {itemType === 'gallery' && (
                            <div className="space-y-4 border-t border-slate-100 pt-4">
                                <div className="flex justify-between">
                                     <h4 className="font-bold text-slate-700">Fotos do Álbum</h4>
                                     <span className="text-xs font-bold bg-blue-100 text-blue-800 px-2 py-1 rounded-full">{galleryFiles.length} Selecionadas</span>
                                </div>
                                <label className="flex items-center justify-center gap-2 w-full py-4 border-2 border-dashed border-slate-300 rounded-xl cursor-pointer hover:bg-slate-50 transition-colors">
                                    <UploadCloud className="w-5 h-5 text-slate-400" />
                                    <span className="text-sm font-bold text-slate-600">Adicionar Fotos da Galeria</span>
                                    <input 
                                        type="file" 
                                        multiple 
                                        accept="image/*"
                                        className="hidden"
                                        onChange={(e) => handleFileChange(e, true)}
                                    />
                                </label>
                            </div>
                        )}

                        {/* PARTNER SPECIFIC */}
                        {itemType === 'partners' && (
                             <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <div className="flex justify-between items-center mb-1">
                                        <label className="block text-xs font-bold text-slate-500 uppercase">Categoria</label>
                                        <button 
                                            type="button" 
                                            onClick={handleAddCategory}
                                            className="text-[10px] text-blue-600 font-bold hover:underline flex items-center gap-1"
                                        >
                                            <Plus className="w-3 h-3" /> Nova
                                        </button>
                                    </div>
                                    <select 
                                        className="w-full border border-slate-200 rounded-lg p-3 bg-white focus:ring-2 focus:ring-blue-500 outline-none text-slate-700"
                                        value={editingItem.category || ''}
                                        onChange={e => setEditingItem({...editingItem, category: e.target.value})}
                                    >
                                        <option value="">Selecione...</option>
                                        {partnerCategories.map(cat => (
                                            <option key={cat} value={cat}>{cat}</option>
                                        ))}
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Desconto Oferta</label>
                                    <input 
                                        type="text" 
                                        className="w-full border border-slate-200 rounded-lg p-3"
                                        value={editingItem.discount || ''}
                                        onChange={e => setEditingItem({...editingItem, discount: e.target.value})}
                                    />
                                </div>
                            </div>
                        )}
                        
                        {/* BOARD/TEAM SPECIFIC */}
                        {(itemType === 'board_members' || itemType === 'team_members') && (
                             <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Cargo / Função</label>
                                <input 
                                    type="text" 
                                    className="w-full border border-slate-200 rounded-lg p-3"
                                    value={editingItem.role || ''}
                                    onChange={e => setEditingItem({...editingItem, role: e.target.value})}
                                />
                            </div>
                        )}

                        <div className="pt-4 flex gap-3 border-t border-slate-100">
                            <button 
                                type="button"
                                onClick={() => setIsModalOpen(false)}
                                className="flex-1 py-3 rounded-xl border border-slate-200 text-slate-600 font-bold hover:bg-slate-50 transition-colors"
                            >
                                Cancelar
                            </button>
                            <button 
                                type="submit"
                                disabled={isLoading}
                                className="flex-1 py-3 rounded-xl bg-blue-600 text-white font-bold hover:bg-blue-700 shadow-lg shadow-blue-600/20 flex items-center justify-center gap-2 transition-colors disabled:opacity-70"
                            >
                                {isLoading ? 'Salvando...' : <><Save className="w-4 h-4" /> Salvar Alterações</>}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        );
    };
    
    // --- MAIN RENDER ---
    return (
        <div className="min-h-screen bg-slate-100 flex font-sans">
            <EditModal />

            {/* Notification Toast */}
            {notification && (
                <div className="fixed top-6 right-6 bg-slate-800 text-white px-6 py-3 rounded-xl shadow-2xl flex items-center gap-3 z-[70] animate-in slide-in-from-right">
                    <CheckCircle2 className="w-5 h-5 text-green-400" />
                    <span className="font-bold text-sm">{notification}</span>
                </div>
            )}

            {/* Sidebar */}
            <aside className="w-64 bg-slate-900 text-white flex flex-col fixed h-full z-20">
                <div className="p-6 border-b border-slate-800 flex items-center gap-3">
                    <div className="p-2 bg-blue-600 rounded-lg">
                        <LayoutGrid className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="font-bold text-lg leading-none">CDL Admin</h1>
                        <span className="text-[10px] text-slate-400 tracking-wider">GESTÃO DIGITAL</span>
                    </div>
                </div>

                <nav className="flex-1 p-4 space-y-1 overflow-y-auto custom-scrollbar">
                    <p className="px-4 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-2">Principal</p>
                    <NavButton icon={LayoutGrid} label="Dashboard" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
                    <NavButton icon={MapPin} label="Empresas & Mapa" active={activeTab === 'companies'} onClick={() => setActiveTab('companies')} />
                    
                    <p className="px-4 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-4">Conteúdo</p>
                    <NavButton icon={Users} label="Institucional" active={activeTab === 'institutional'} onClick={() => setActiveTab('institutional')} />
                    <NavButton icon={ImageIcon} label="Galeria de Fotos" active={activeTab === 'gallery'} onClick={() => setActiveTab('gallery')} />
                    <NavButton icon={FileText} label="Notícias & Blog" active={activeTab === 'content'} onClick={() => setActiveTab('content')} />
                    <NavButton icon={ShoppingBag} label="Loja & Eventos" active={activeTab === 'products'} onClick={() => setActiveTab('products')} />
                    <NavButton icon={Calendar} label="Calendário" active={activeTab === 'calendar'} onClick={() => setActiveTab('calendar')} />
                    
                    <p className="px-4 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-4">Ferramentas</p>
                    <NavButton icon={Percent} label="Clube de Vantagens" active={activeTab === 'partners'} onClick={() => setActiveTab('partners')} />
                    <NavButton icon={TrendingUp} label="Indicadores" active={activeTab === 'indicators'} onClick={() => setActiveTab('indicators')} />
                </nav>

                <div className="p-4 border-t border-slate-800">
                    <button onClick={onLogout} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-400 hover:bg-red-500/10 transition-colors text-sm font-bold">
                        <LogOut className="w-5 h-5" /> Sair do Sistema
                    </button>
                </div>
            </aside>

            {/* Main Area */}
            <main className="flex-1 ml-64 p-8">
                {isLoading && (
                    <div className="fixed top-0 left-0 w-full h-1 bg-blue-100 z-[100]">
                        <div className="h-full bg-blue-600 animate-[progress_1s_infinite]"></div>
                    </div>
                )}

                {activeTab === 'dashboard' && (
                    <div className="flex flex-col items-center justify-center h-full text-center text-slate-400">
                        <Settings className="w-16 h-16 mb-4 text-slate-300" />
                        <h2 className="text-xl font-bold text-slate-600">Bem-vindo ao Painel</h2>
                        <p>Selecione um módulo no menu lateral para começar a gerenciar.</p>
                        <p className="text-xs mt-4 text-green-600 font-bold bg-green-50 px-3 py-1 rounded-full">● Conectado ao Supabase</p>
                    </div>
                )}
                {activeTab === 'institutional' && renderInstitutionalManager()}
                {activeTab === 'partners' && renderPartnersManager()}
                {activeTab === 'gallery' && renderGalleryManager()}
                {activeTab === 'content' && renderNewsManager()}
                
                {/* Placeholder para outras abas */}
                {(activeTab === 'products' || activeTab === 'calendar' || activeTab === 'companies' || activeTab === 'indicators') && (
                     <div className="text-center py-12 bg-white rounded-3xl border border-slate-100">
                        <FileText className="w-12 h-12 text-blue-200 mx-auto mb-4" />
                        <h3 className="text-lg font-bold text-slate-800">Módulo em Desenvolvimento</h3>
                        <p className="text-slate-500">As funcionalidades de edição para esta seção estão sendo finalizadas.</p>
                    </div>
                )}
            </main>
        </div>
    );
};

const NavButton: React.FC<{ icon: any, label: string, active: boolean, onClick: () => void }> = ({ icon: Icon, label, active, onClick }) => (
    <button 
        onClick={onClick}
        className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all text-sm font-medium ${active ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50 translate-x-1' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
    >
        <Icon className={`w-4 h-4 ${active ? 'text-white' : 'text-slate-500'}`} />
        {label}
    </button>
);

export default AdminDashboard;
