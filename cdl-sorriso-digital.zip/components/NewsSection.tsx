
import React from 'react';
import { Calendar, ArrowRight } from 'lucide-react';
import { NewsPost } from '../types';

interface Props {
  news: NewsPost[];
  onViewNews?: (post: NewsPost) => void;
}

const NewsSection: React.FC<Props> = ({ news, onViewNews }) => {
  return (
    <section className="py-20 bg-slate-50" id="noticias">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-end mb-12">
          <div>
            <span className="text-blue-600 font-bold tracking-wider text-sm uppercase mb-2 block">Fique por dentro</span>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-800">Notícias & Eventos</h2>
          </div>
          <button className="hidden md:flex items-center gap-2 text-blue-600 font-semibold hover:text-blue-800 transition-colors">
            Ver todas as notícias
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {news.map((item) => (
            <article 
                key={item.id} 
                onClick={() => onViewNews && onViewNews(item)}
                className="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 group flex flex-col h-full border border-slate-100 cursor-pointer"
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute top-4 left-4">
                    <span className="bg-blue-900/90 backdrop-blur-md text-white text-xs font-bold px-3 py-1 rounded-lg">
                        {item.category}
                    </span>
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex items-center gap-2 text-slate-400 text-xs font-medium mb-3">
                    <Calendar className="w-3.5 h-3.5" />
                    {item.date}
                </div>
                <h3 className="text-xl font-bold text-slate-800 mb-3 group-hover:text-blue-700 transition-colors">
                  {item.title}
                </h3>
                <p className="text-slate-500 text-sm leading-relaxed mb-4 flex-1">
                  {item.excerpt}
                </p>
                <button className="inline-flex items-center text-blue-600 font-bold text-sm hover:underline decoration-2 underline-offset-4">
                  Ler notícia completa
                </button>
              </div>
            </article>
          ))}
        </div>
        
        <div className="mt-8 text-center md:hidden">
            <button className="px-6 py-3 border border-slate-300 rounded-xl text-slate-600 font-bold hover:bg-slate-50 transition-colors">
                Ver todas as notícias
            </button>
        </div>
      </div>
    </section>
  );
};

export default NewsSection;
