
import React, { useState } from 'react';
import { ArrowLeft, Search, MapPin, Navigation, Phone, MessageCircle, Star } from 'lucide-react';
import { BUSINESS_DATA } from '../constants';
import { Business } from '../types';

interface Props {
    onBack: () => void;
}

const CommercialGuideMap: React.FC<Props> = ({ onBack }) => {
    const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const filteredBusinesses = BUSINESS_DATA.filter(b => 
        b.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        b.category.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="flex h-screen w-full bg-white fixed inset-0 z-50">
            {/* Sidebar List */}
            <div className="w-full md:w-[400px] flex flex-col border-r border-slate-200 bg-white h-full shadow-xl z-20">
                <div className="p-4 border-b border-slate-100 bg-blue-900 text-white">
                    <button onClick={onBack} className="flex items-center gap-2 text-sm font-bold text-white/80 hover:text-white mb-4">
                        <ArrowLeft className="w-4 h-4" /> Voltar ao Site
                    </button>
                    <h2 className="text-xl font-bold mb-1">Guia Comercial</h2>
                    <p className="text-blue-200 text-xs">Explore 1.500+ empresas em Sorriso</p>
                    
                    <div className="mt-4 relative">
                        <Search className="absolute left-3 top-2.5 w-4 h-4 text-blue-900/50" />
                        <input 
                            type="text" 
                            placeholder="Buscar empresa ou categoria..." 
                            className="w-full pl-10 pr-4 py-2 rounded-lg text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-yellow-400 shadow-sm"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto">
                    {filteredBusinesses.map(business => (
                        <div 
                            key={business.id}
                            onClick={() => setSelectedBusiness(business)}
                            className={`p-4 border-b border-slate-50 hover:bg-slate-50 cursor-pointer transition-colors ${selectedBusiness?.id === business.id ? 'bg-blue-50 border-l-4 border-l-blue-600' : ''}`}
                        >
                            <div className="flex gap-3">
                                <img src={business.image} alt={business.name} className="w-16 h-16 rounded-lg object-cover bg-slate-200" />
                                <div>
                                    <h3 className="font-bold text-slate-800 text-sm">{business.name}</h3>
                                    <span className="text-xs font-bold text-slate-500 uppercase tracking-wide">{business.category}</span>
                                    <div className="flex items-center gap-1 mt-1">
                                        <Star className="w-3 h-3 text-yellow-400 fill-current" />
                                        <span className="text-xs text-slate-600 font-medium">{business.rating}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Map Area */}
            <div className="flex-1 bg-slate-100 relative">
                {/* Simulated Map Background */}
                <div className="absolute inset-0 bg-[#e5e7eb] flex items-center justify-center overflow-hidden">
                    <div className="text-slate-400 text-center opacity-50 select-none pointer-events-none">
                        <MapPin className="w-24 h-24 mx-auto mb-4" />
                        <h3 className="text-2xl font-bold">Mapa de Sorriso Interativo</h3>
                        <p>Google Maps API Integration Area</p>
                    </div>
                    {/* Simulated Pins */}
                    {filteredBusinesses.map((b, i) => (
                        <div 
                            key={b.id}
                            className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer group"
                            style={{ 
                                top: `${50 + (Math.random() * 40 - 20)}%`, 
                                left: `${50 + (Math.random() * 40 - 20)}%` 
                            }}
                            onClick={() => setSelectedBusiness(b)}
                        >
                            <div className={`w-8 h-8 rounded-full border-2 border-white shadow-lg flex items-center justify-center transform transition-transform group-hover:scale-125 ${selectedBusiness?.id === b.id ? 'bg-blue-600 scale-125 z-50' : 'bg-red-500 z-10'}`}>
                                <Building className="w-4 h-4 text-white" />
                            </div>
                        </div>
                    ))}
                </div>

                {/* Floating Business Detail Card */}
                {selectedBusiness && (
                    <div className="absolute bottom-8 left-8 right-8 md:left-auto md:right-8 md:w-96 bg-white rounded-2xl shadow-2xl p-6 animate-in slide-in-from-bottom-10 fade-in duration-300">
                        <button onClick={() => setSelectedBusiness(null)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600">×</button>
                        <div className="flex gap-4 mb-4">
                            <img src={selectedBusiness.image} className="w-20 h-20 rounded-xl object-cover" alt="" />
                            <div>
                                <h3 className="font-bold text-lg text-slate-800 leading-tight">{selectedBusiness.name}</h3>
                                <p className="text-slate-500 text-sm">{selectedBusiness.category}</p>
                                <div className="flex items-center gap-1 mt-1 text-green-600 text-xs font-bold">
                                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                                    Aberto Agora
                                </div>
                            </div>
                        </div>
                        <div className="space-y-3 mb-6">
                            <div className="flex items-center gap-3 text-sm text-slate-600">
                                <MapPin className="w-4 h-4 text-blue-500" />
                                {selectedBusiness.address}
                            </div>
                             <div className="flex items-center gap-3 text-sm text-slate-600">
                                <Phone className="w-4 h-4 text-blue-500" />
                                {selectedBusiness.phone}
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                            <button className="flex items-center justify-center gap-2 bg-blue-600 text-white py-2.5 rounded-xl font-bold text-sm hover:bg-blue-700 transition-colors">
                                <Navigation className="w-4 h-4" /> Como Chegar
                            </button>
                            <button className="flex items-center justify-center gap-2 bg-green-500 text-white py-2.5 rounded-xl font-bold text-sm hover:bg-green-600 transition-colors">
                                <MessageCircle className="w-4 h-4" /> WhatsApp
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

import { Building } from 'lucide-react';
export default CommercialGuideMap;
