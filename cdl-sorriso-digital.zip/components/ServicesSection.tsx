
import React from 'react';
import { ShieldCheck, CreditCard, Smartphone, Gavel, ChevronRight, QrCode, Building2, Megaphone } from 'lucide-react';
import { SERVICES_DATA } from '../constants';
import { Service } from '../types';

interface Props {
    onViewService?: (service: Service) => void;
}

const ServicesSection: React.FC<Props> = ({ onViewService }) => {
  
  // Helper to map string icon names back to components if needed, though we can just look at index or name
  const getIcon = (name: string) => {
      switch(name) {
          case 'ShieldCheck': return <ShieldCheck className="w-8 h-8 text-white" />;
          case 'CreditCard': return <CreditCard className="w-8 h-8 text-white" />;
          case 'Building2': return <Building2 className="w-8 h-8 text-white" />;
          case 'Smartphone': return <Smartphone className="w-8 h-8 text-white" />;
          case 'Megaphone': return <Megaphone className="w-8 h-8 text-white" />;
          case 'Gavel': return <Gavel className="w-8 h-8 text-white" />;
          default: return <ShieldCheck className="w-8 h-8 text-white" />;
      }
  };

  return (
    <section className="py-24 bg-white relative overflow-hidden" id="servicos">
        {/* Decorative Blobs */}
        <div className="absolute -left-20 top-20 w-64 h-64 bg-blue-50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob"></div>
        <div className="absolute -right-20 bottom-20 w-64 h-64 bg-yellow-50 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-2000"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16 max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-5xl font-bold text-slate-800 mb-6">
            Soluções para <span className="relative inline-block">
                Impulsionar
                <span className="absolute bottom-2 left-0 w-full h-3 bg-yellow-300/50 -z-10 rounded-sm"></span>
            </span> seu Negócio
          </h2>
          <p className="text-slate-500 text-lg">
            A CDL Sorriso oferece um portfólio completo de ferramentas e benefícios desenhados para acelerar o crescimento da sua empresa.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES_DATA.map((service) => (
            <div 
                key={service.id} 
                onClick={() => onViewService && onViewService(service)}
                className="group p-8 rounded-3xl bg-white border border-slate-100 hover:border-blue-100 shadow-lg shadow-slate-200/50 hover:shadow-xl hover:shadow-blue-900/5 transition-all duration-300 hover:-translate-y-2 flex flex-col cursor-pointer"
            >
              <div className="flex items-center justify-between mb-6">
                  <div className={`w-16 h-16 rounded-2xl ${service.color} flex items-center justify-center shadow-lg shadow-slate-300 transform group-hover:rotate-3 transition-transform duration-300`}>
                    {service.icon || getIcon(service.iconName || '')}
                  </div>
                  <span className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-300 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <ChevronRight className="w-4 h-4" />
                  </span>
              </div>
              
              <h3 className="text-xl font-bold text-slate-800 mb-3 group-hover:text-blue-700 transition-colors">{service.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed mb-6 flex-1">
                {service.description}
              </p>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
             <button className="bg-slate-900 text-white font-bold py-4 px-8 rounded-full hover:bg-slate-800 transition-all shadow-lg flex items-center gap-2 mx-auto">
                <QrCode className="w-5 h-5" />
                Ver Guia de Benefícios Completo
             </button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
