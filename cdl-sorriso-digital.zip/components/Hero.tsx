import React, { useState, useEffect } from 'react';
import { Search, MapPin, FileCheck, ShieldAlert, UserPlus, ChevronDown, ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { HERO_SLIDES } from '../constants';

interface Props {
  onSearch: (term: string) => void;
}

const Hero: React.FC<Props> = ({ onSearch }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const slideDuration = 10000; // 10 seconds

  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, slideDuration);

    return () => clearInterval(interval);
  }, [isPaused]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? HERO_SLIDES.length - 1 : prev - 1));
  };

  const slide = HERO_SLIDES[currentSlide];

  return (
    <div className="relative h-[900px] flex items-center justify-center" id="inicio"
         onMouseEnter={() => setIsPaused(true)}
         onMouseLeave={() => setIsPaused(false)}>
      
      {/* Background Slider Container (Isolated with overflow-hidden) */}
      <div className="absolute inset-0 overflow-hidden rounded-b-[3rem] z-0">
          {HERO_SLIDES.map((s, index) => (
            <div 
                key={s.id}
                className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${index === currentSlide ? 'opacity-100' : 'opacity-0'}`}
            >
                {/* Image with Slow Zoom Effect (Ken Burns) */}
                <div 
                    className={`absolute inset-0 bg-cover bg-center transition-transform duration-[10000ms] ease-linear ${index === currentSlide ? 'scale-110' : 'scale-100'}`}
                    style={{ backgroundImage: `url("${s.image}")` }}
                ></div>
                {/* Gradient Overlays */}
                <div className="absolute inset-0 bg-gradient-to-b from-blue-900/90 via-blue-900/50 to-slate-50/90"></div>
                <div className="absolute inset-0 bg-gradient-to-r from-blue-900/60 to-transparent"></div>
            </div>
          ))}
      </div>

      {/* Content Container */}
      <div className="relative z-10 container mx-auto px-4 flex flex-col items-center pt-48 h-full justify-start">
        
        {/* Dynamic Text Content */}
        <div key={currentSlide} className="text-center max-w-4xl mx-auto mb-8 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
             {/* Badge */}
            <div className="inline-flex items-center gap-2 py-1.5 px-4 rounded-full bg-white/10 border border-white/20 text-white text-xs font-bold uppercase tracking-widest backdrop-blur-md shadow-lg">
                <span className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse"></span>
                {slide.badge}
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-white leading-tight tracking-tight drop-shadow-lg">
                {slide.title} <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-yellow-200">
                    {slide.highlight}
                </span>
            </h1>
            
            <p className="text-lg text-blue-100 max-w-2xl mx-auto font-light leading-relaxed drop-shadow-md">
                {slide.description}
            </p>

            {/* CTA Button */}
            <div className="pt-6">
                <a href={slide.ctaLink} className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-white/10 hover:bg-white hover:text-blue-900 text-white border border-white/30 font-bold transition-all backdrop-blur-sm group text-lg">
                    {slide.ctaText}
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </a>
            </div>
        </div>

        {/* Search Box - Positioned higher to avoid bottom cards */}
        <div className="w-full max-w-3xl mx-auto bg-white/95 backdrop-blur-md p-2 rounded-[2rem] shadow-2xl shadow-blue-900/40 flex flex-col md:flex-row gap-2 transform hover:scale-[1.01] transition-all duration-300 relative z-20 mt-auto mb-48 border border-white/50">
          <div className="flex-1 flex items-center px-6 h-14 md:h-16 bg-slate-50/50 rounded-[1.5rem] border-2 border-transparent focus-within:border-blue-100 focus-within:bg-white transition-all group">
            <Search className="w-5 h-5 text-slate-400 group-focus-within:text-blue-600 transition-colors" />
            <input 
              type="text" 
              placeholder="Busque por empresas, serviços ou produtos..."
              className="w-full h-full bg-transparent outline-none text-slate-700 placeholder-slate-400 font-medium ml-3"
              onChange={(e) => onSearch(e.target.value)}
            />
          </div>
          
          <button className="h-14 md:h-16 px-8 md:px-10 bg-blue-600 hover:bg-blue-700 text-white font-bold text-lg rounded-[1.5rem] shadow-lg hover:shadow-blue-600/30 transition-all active:scale-95 flex items-center justify-center gap-2">
            Buscar
          </button>
        </div>

        {/* Slider Controls & Progress */}
        <div className="absolute bottom-44 w-full max-w-4xl flex items-center justify-between px-4 text-white/50 pointer-events-none">
            <button onClick={prevSlide} className="pointer-events-auto p-2 hover:bg-white/10 rounded-full transition-colors hover:text-white">
                <ChevronLeft className="w-8 h-8" />
            </button>
             <button onClick={nextSlide} className="pointer-events-auto p-2 hover:bg-white/10 rounded-full transition-colors hover:text-white">
                <ChevronRight className="w-8 h-8" />
            </button>
        </div>

        {/* Progress Bar Indicators */}
        <div className="absolute bottom-36 flex gap-2 z-20">
            {HERO_SLIDES.map((_, idx) => (
                <button 
                    key={idx} 
                    onClick={() => setCurrentSlide(idx)}
                    className="group relative h-1.5 rounded-full overflow-hidden bg-white/20 transition-all duration-300"
                    style={{ width: idx === currentSlide ? '40px' : '12px' }}
                >
                    {idx === currentSlide && (
                        <div 
                            className={`absolute inset-0 bg-yellow-400 ${isPaused ? '' : 'animate-[progress_10s_linear]'}`}
                            style={{ animationPlayState: isPaused ? 'paused' : 'running' }}
                        ></div>
                    )}
                </button>
            ))}
        </div>

        {/* Quick Actions Cards - Floating OUTSIDE the overflow hidden area effectively */}
        <div className="absolute -bottom-16 grid grid-cols-2 md:grid-cols-4 gap-4 w-full max-w-5xl px-4 z-30">
            {[
                { label: 'Consulta CPF/CNPJ', icon: ShieldAlert, color: 'text-blue-600', bg: 'bg-blue-50' },
                { label: 'Certificado Digital', icon: FileCheck, color: 'text-green-600', bg: 'bg-green-50' },
                { label: 'Seja Associado', icon: UserPlus, color: 'text-yellow-600', bg: 'bg-yellow-50' },
                { label: 'Guia Comercial', icon: MapPin, color: 'text-purple-600', bg: 'bg-purple-50' },
            ].map((item, idx) => (
                <button key={idx} className="bg-white p-6 rounded-2xl shadow-xl shadow-blue-900/10 hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 border border-slate-100 flex flex-col items-center justify-center gap-3 group h-36">
                    <div className={`w-14 h-14 rounded-2xl ${item.bg} flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-sm`}>
                        <item.icon className={`w-7 h-7 ${item.color}`} />
                    </div>
                    <span className="font-bold text-slate-700 text-sm group-hover:text-blue-900 text-center">{item.label}</span>
                </button>
            ))}
        </div>
      </div>

      <style>{`
        @keyframes progress {
            from { width: 0%; }
            to { width: 100%; }
        }
      `}</style>
    </div>
  );
};

export default Hero;