
import React from 'react';
import { Play, Clock, Calendar, Share2, Youtube, Mic } from 'lucide-react';

const TVLojista: React.FC = () => {
  const mainVideo = {
    title: "Palavra do Presidente: Balanço 2023 e Metas 2024",
    description: "Nosso presidente Paulo Silveira faz um balanço das ações realizadas no último ano e apresenta o planejamento estratégico para fortalecer o comércio de Sorriso.",
    duration: "15 min",
    date: "Há 1 semana",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80"
  };

  const episodes = [
    {
      id: 1,
      title: "Lançamento Natal Premiado CDL Sorriso",
      duration: "45 min",
      type: "Evento",
      image: "https://images.unsplash.com/photo-1512909006721-3d6018887383?auto=format&fit=crop&w=600&q=80"
    },
    {
      id: 2,
      title: "Café com Empresários: Inovação no Varejo",
      duration: "30 min",
      type: "Palestras",
      image: "https://images.unsplash.com/photo-1515169067750-d51a73b50981?auto=format&fit=crop&w=600&q=80"
    },
    {
      id: 3,
      title: "Tutorial: Como emitir seu Certificado Digital",
      duration: "5 min",
      type: "Institucional",
      image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=600&q=80"
    }
  ];

  return (
    <section className="py-20 bg-slate-900 text-white overflow-hidden relative" id="tv-cdl">
      {/* Background Ambient Glow */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-[100px]"></div>
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-yellow-500/10 rounded-full blur-[100px]"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex items-center justify-between mb-12">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-red-600 rounded-xl shadow-lg shadow-red-600/20">
              <Youtube className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-3xl md:text-4xl font-bold">TV Lojista</h2>
              <p className="text-slate-400 text-sm">Canal Oficial @cdlsorriso2976</p>
            </div>
          </div>
          <a 
            href="https://www.youtube.com/@cdlsorriso2976" 
            target="_blank" 
            rel="noreferrer"
            className="hidden md:flex items-center gap-2 text-sm font-bold text-white/80 hover:text-white hover:bg-white/10 px-4 py-2 rounded-full transition-all"
          >
             Acessar Canal Oficial <Share2 className="w-4 h-4" />
          </a>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Feature */}
          <div className="lg:col-span-2 group relative rounded-3xl overflow-hidden aspect-video lg:aspect-auto shadow-2xl shadow-black/50 cursor-pointer">
            <img 
              src={mainVideo.image} 
              alt={mainVideo.title} 
              className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent opacity-90"></div>
            
            <div className="absolute bottom-0 left-0 p-8 w-full">
              <span className="inline-block px-3 py-1 bg-yellow-500 text-black text-xs font-bold rounded-md mb-4 uppercase tracking-wider">
                Destaque Institucional
              </span>
              <h3 className="text-2xl md:text-4xl font-bold mb-3 leading-tight">{mainVideo.title}</h3>
              <p className="text-slate-300 mb-6 line-clamp-2 md:line-clamp-none max-w-2xl">
                {mainVideo.description}
              </p>
              
              <div className="flex items-center gap-4">
                <a 
                  href="https://www.youtube.com/@cdlsorriso2976"
                  target="_blank"
                  rel="noreferrer" 
                  className="flex items-center gap-2 bg-white text-black px-6 py-3 rounded-full font-bold hover:bg-blue-50 transition-colors"
                >
                  <Play className="w-5 h-5 fill-current" />
                  Assistir Agora
                </a>
                <div className="flex items-center gap-4 text-sm text-slate-400">
                  <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {mainVideo.duration}</span>
                  <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> {mainVideo.date}</span>
                </div>
              </div>
            </div>
            
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center border border-white/50 opacity-0 group-hover:opacity-100 transition-all duration-300 transform scale-50 group-hover:scale-100">
                <Play className="w-6 h-6 text-white fill-white" />
            </div>
          </div>

          {/* Sidebar List */}
          <div className="flex flex-col gap-4">
            <h4 className="font-bold text-lg text-slate-200 mb-2">Últimos Vídeos</h4>
            {episodes.map((ep) => (
              <div key={ep.id} className="group flex gap-4 p-3 rounded-xl hover:bg-white/5 transition-colors cursor-pointer">
                <div className="relative w-32 h-20 flex-shrink-0 rounded-lg overflow-hidden">
                  <img src={ep.image} alt={ep.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-6 h-6 text-white drop-shadow-lg" />
                  </div>
                  <span className="absolute bottom-1 right-1 bg-black/80 text-white text-[10px] px-1.5 rounded">
                    {ep.duration}
                  </span>
                </div>
                <div className="flex flex-col justify-center">
                  <div className="flex items-center gap-2 mb-1">
                     {ep.type === 'Podcast' ? <Mic className="w-3 h-3 text-blue-400" /> : <Youtube className="w-3 h-3 text-red-400" />}
                     <span className="text-[10px] font-bold uppercase text-slate-400">{ep.type}</span>
                  </div>
                  <h5 className="text-sm font-bold text-slate-100 group-hover:text-yellow-400 transition-colors line-clamp-2 leading-snug">
                    {ep.title}
                  </h5>
                </div>
              </div>
            ))}
            
            <div className="mt-auto pt-4 border-t border-white/10">
                <a 
                  href="https://www.youtube.com/@cdlsorriso2976"
                  target="_blank"
                  rel="noreferrer"
                  className="block w-full py-3 text-center rounded-xl border border-white/20 text-sm font-bold hover:bg-white hover:text-black transition-all"
                >
                    Ver Canal da CDL
                </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TVLojista;
