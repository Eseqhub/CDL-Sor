import React from 'react';
import { MapPin, Phone, BadgeCheck, Star, MessageCircle, ArrowRight } from 'lucide-react';
import { Business } from '../types';

interface Props {
  business: Business;
}

const BusinessCard: React.FC<Props> = ({ business }) => {
  return (
    <div className="group bg-white rounded-2xl overflow-hidden hover:shadow-[0_20px_50px_rgba(8,_112,_184,_0.1)] transition-all duration-500 border border-slate-100 flex flex-col h-full relative top-0 hover:-top-2">
      <div className="relative h-48 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent z-10 opacity-60 group-hover:opacity-40 transition-opacity"></div>
        <img 
          src={business.image} 
          alt={business.name} 
          className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute top-4 left-4 z-20">
          <span className="bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold text-slate-800 uppercase tracking-wider shadow-sm border border-white/50">
            {business.category}
          </span>
        </div>
        {business.verified && (
            <div className="absolute top-4 right-4 z-20 bg-blue-600 text-white p-1.5 rounded-full shadow-lg shadow-blue-600/20 animate-pulse-soft" title="Associado Verificado">
                <BadgeCheck className="w-4 h-4" />
            </div>
        )}
      </div>
      
      <div className="p-6 flex-1 flex flex-col">
        <div className="mb-3">
            <h3 className="text-lg font-bold text-slate-800 group-hover:text-blue-600 transition-colors line-clamp-1 mb-1">
                {business.name}
            </h3>
            <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                    <Star 
                    key={i} 
                    className={`w-3 h-3 ${i < Math.floor(business.rating) ? 'text-yellow-400 fill-current' : 'text-slate-200'}`} 
                    />
                ))}
                <span className="text-xs text-slate-400 font-medium ml-1">{business.rating}</span>
            </div>
        </div>

        <p className="text-slate-500 text-sm mb-6 line-clamp-2 leading-relaxed">
          {business.description}
        </p>

        <div className="space-y-3 mt-auto border-t border-slate-50 pt-4">
          <div className="flex items-start text-slate-500 text-xs font-medium">
            <MapPin className="w-3.5 h-3.5 mr-2 text-blue-400 flex-shrink-0" />
            <span className="line-clamp-1 group-hover:text-blue-600 transition-colors">{business.address}</span>
          </div>
          
          <div className="grid grid-cols-2 gap-2 mt-2">
             <a 
                href={`tel:${business.phone.replace(/\D/g,'')}`}
                className="flex items-center justify-center gap-1.5 py-2 rounded-lg bg-slate-50 text-slate-600 text-xs font-bold hover:bg-blue-600 hover:text-white transition-all"
             >
                <Phone className="w-3 h-3" />
                Ligar
             </a>
             <a 
                href={business.whatsapp ? `https://wa.me/${business.whatsapp}` : '#'}
                className="flex items-center justify-center gap-1.5 py-2 rounded-lg bg-green-50 text-green-700 text-xs font-bold hover:bg-green-500 hover:text-white transition-all"
             >
                <MessageCircle className="w-3 h-3" />
                WhatsApp
             </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BusinessCard;