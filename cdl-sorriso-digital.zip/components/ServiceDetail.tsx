
import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, MessageCircle, Send } from 'lucide-react';
import { Service } from '../types';

interface Props {
  service: Service;
  onBack: () => void;
}

const ServiceDetail: React.FC<Props> = ({ service, onBack }) => {
  const [formState, setFormState] = useState({ name: '', phone: '', company: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 animate-in slide-in-from-right duration-300">
       <div className={`bg-slate-900 text-white py-20 relative overflow-hidden`}>
            <div className={`absolute inset-0 opacity-20 ${service.color}`}></div>
             <div className="container mx-auto px-4 relative z-10">
                 <button onClick={onBack} className="flex items-center gap-2 text-white/70 hover:text-white font-bold mb-8 transition-colors">
                    <ArrowLeft className="w-5 h-5" /> Voltar para Home
                 </button>
                 <div className="max-w-3xl">
                    <span className="inline-block border border-white/30 bg-white/10 backdrop-blur-sm px-4 py-1 rounded-full text-sm font-bold mb-4">Serviço Exclusivo CDL</span>
                    <h1 className="text-4xl md:text-6xl font-bold mb-6">{service.title}</h1>
                    <p className="text-xl text-blue-100 leading-relaxed">{service.description}</p>
                 </div>
             </div>
       </div>

       <div className="container mx-auto px-4 -mt-10 relative z-20 pb-20">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <div className="lg:col-span-7">
                    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-8 md:p-12">
                        <h3 className="text-2xl font-bold text-slate-800 mb-6">Por que contratar?</h3>
                        <div className="space-y-6">
                            {[
                                'Atendimento prioritário e suporte especializado',
                                'Condições exclusivas para associados CDL',
                                'Agilidade e desburocratização do processo',
                                'Segurança e credibilidade da marca CDL Sorriso'
                            ].map((item, i) => (
                                <div key={i} className="flex items-start gap-4">
                                    <div className="p-1 bg-green-100 rounded-full mt-1">
                                        <CheckCircle2 className="w-5 h-5 text-green-600" />
                                    </div>
                                    <p className="text-slate-600 font-medium text-lg">{item}</p>
                                </div>
                            ))}
                        </div>
                        
                        <div className="mt-12 p-6 bg-blue-50 rounded-2xl border border-blue-100">
                            <h4 className="font-bold text-blue-900 mb-2 flex items-center gap-2">
                                <MessageCircle className="w-5 h-5" /> Dúvidas?
                            </h4>
                            <p className="text-blue-700">
                                Nossa equipe está pronta para te atender pelo WhatsApp ou telefone. <br/>
                                <strong>(66) 99650-7301</strong>
                            </p>
                        </div>
                    </div>
                </div>

                <div className="lg:col-span-5">
                    <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8 sticky top-24">
                        {!submitted ? (
                            <>
                                <h3 className="text-xl font-bold text-slate-800 mb-2">Tenho Interesse</h3>
                                <p className="text-slate-500 text-sm mb-6">Preencha para receber um contato comercial.</p>
                                <form onSubmit={handleSubmit} className="space-y-4">
                                    <div>
                                        <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Seu Nome</label>
                                        <input 
                                            required
                                            type="text" 
                                            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                                            value={formState.name}
                                            onChange={e => setFormState({...formState, name: e.target.value})}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-600 uppercase mb-1">WhatsApp</label>
                                        <input 
                                            required
                                            type="tel" 
                                            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                                            value={formState.phone}
                                            onChange={e => setFormState({...formState, phone: e.target.value})}
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-slate-600 uppercase mb-1">Empresa (Opcional)</label>
                                        <input 
                                            type="text" 
                                            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 focus:ring-2 focus:ring-blue-500 outline-none"
                                            value={formState.company}
                                            onChange={e => setFormState({...formState, company: e.target.value})}
                                        />
                                    </div>
                                    <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-600/20 transition-all flex items-center justify-center gap-2 mt-4">
                                        Solicitar Contato <Send className="w-4 h-4" />
                                    </button>
                                </form>
                            </>
                        ) : (
                            <div className="text-center py-12">
                                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4 text-green-600">
                                    <CheckCircle2 className="w-8 h-8" />
                                </div>
                                <h3 className="text-xl font-bold text-slate-800 mb-2">Solicitação Enviada!</h3>
                                <p className="text-slate-500">Em breve nossa equipe entrará em contato pelo número informado.</p>
                                <button onClick={() => setSubmitted(false)} className="text-blue-600 font-bold text-sm mt-6 hover:underline">
                                    Enviar nova solicitação
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
       </div>
    </div>
  );
};

export default ServiceDetail;
