
import React from 'react';
import { TrendingUp } from 'lucide-react';
import { TICKER_NEWS } from '../constants';

const NewsTicker: React.FC = () => {
  return (
    <div className="bg-slate-900 border-t border-slate-800 overflow-hidden h-10 flex items-center relative z-30">
      {/* Label with Clip Path for clean angle */}
      <div 
        className="bg-red-600 text-white h-full px-6 flex items-center gap-2 font-bold text-xs uppercase tracking-wider z-20 shadow-xl flex-shrink-0 relative pr-8"
        style={{ clipPath: 'polygon(0 0, 100% 0, 90% 100%, 0% 100%)' }}
      >
        <TrendingUp className="w-4 h-4" />
        Plantão Varejo
      </div>
      
      <div className="flex-1 overflow-hidden relative h-full flex items-center -ml-4">
        <div className="flex gap-12 animate-[marquee_60s_linear_infinite] pl-8 hover:[animation-play-state:paused]">
          {/* Duplicate list multiple times to ensure no gaps on wide screens */}
          {[...TICKER_NEWS, ...TICKER_NEWS, ...TICKER_NEWS, ...TICKER_NEWS].map((item, index) => (
            <a 
                key={`${item.id}-${index}`} 
                href={item.url} 
                target="_blank" 
                rel="noreferrer"
                className="group flex items-center gap-3 text-slate-300 hover:text-white transition-colors text-xs whitespace-nowrap flex-shrink-0"
            >
                <span className="font-bold text-blue-400">{item.source}:</span>
                <span className="group-hover:underline decoration-slate-500 underline-offset-2">{item.headline}</span>
                <span className="text-[10px] text-slate-600 border border-slate-700 px-1.5 rounded">{item.time}</span>
            </a>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
};

export default NewsTicker;
