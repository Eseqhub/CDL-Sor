import React from 'react';
import { ShoppingBag, Tractor, Utensils, Stethoscope, Monitor, MoreHorizontal, CheckCircle2 } from 'lucide-react';
import { FilterType } from '../types';

interface Props {
  activeFilter: FilterType;
  onSelectCategory: (category: FilterType) => void;
}

const CategoryGrid: React.FC<Props> = ({ activeFilter, onSelectCategory }) => {
  const categories = [
    { id: FilterType.ALL, label: 'Todos', icon: <CheckCircle2 className="w-6 h-6" />, color: 'bg-slate-800' },
    { id: FilterType.RETAIL, label: 'Comércio', icon: <ShoppingBag className="w-6 h-6" />, color: 'bg-pink-500' },
    { id: FilterType.AGRO, label: 'Agro', icon: <Tractor className="w-6 h-6" />, color: 'bg-green-600' },
    { id: FilterType.FOOD, label: 'Gastronomia', icon: <Utensils className="w-6 h-6" />, color: 'bg-orange-500' },
    { id: FilterType.HEALTH, label: 'Saúde', icon: <Stethoscope className="w-6 h-6" />, color: 'bg-cyan-500' },
    { id: FilterType.SERVICES, label: 'Serviços', icon: <Monitor className="w-6 h-6" />, color: 'bg-purple-500' },
  ];

  return (
    <div className="container mx-auto px-4 mt-24 relative z-20">
        <div className="bg-white rounded-3xl shadow-sm p-8 border border-slate-100">
            <div className="text-center mb-6">
                <h3 className="text-slate-400 font-bold text-xs uppercase tracking-widest">Navegue por Setor</h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-6">
                {categories.map((cat) => {
                    const isActive = activeFilter === cat.id;
                    return (
                        <button
                            key={cat.id}
                            onClick={() => onSelectCategory(cat.id)}
                            className={`flex flex-col items-center justify-center p-4 rounded-2xl transition-all duration-300 group ${
                                isActive 
                                ? 'bg-blue-50 ring-2 ring-blue-200 scale-105' 
                                : 'bg-slate-50 hover:bg-white hover:shadow-lg hover:-translate-y-1'
                            }`}
                        >
                            <div className={`w-14 h-14 rounded-full flex items-center justify-center text-white shadow-md mb-3 transition-transform duration-300 group-hover:scale-110 ${cat.color} ${isActive ? 'ring-4 ring-blue-100' : ''}`}>
                                {cat.icon}
                            </div>
                            <span className={`text-sm font-bold ${isActive ? 'text-blue-900' : 'text-slate-600 group-hover:text-slate-900'}`}>
                                {cat.label}
                            </span>
                        </button>
                    )
                })}
            </div>
        </div>
    </div>
  );
};

export default CategoryGrid;