
import React from 'react';
import { ArrowLeft, Calendar, User, Share2 } from 'lucide-react';
import { NewsPost } from '../types';

interface Props {
  news: NewsPost;
  onBack: () => void;
}

const NewsDetail: React.FC<Props> = ({ news, onBack }) => {
  return (
    <div className="min-h-screen bg-white animate-in slide-in-from-right duration-300">
      {/* Header Image */}
      <div className="relative h-[400px] w-full">
        <img src={news.image} alt={news.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
        <div className="absolute top-6 left-4 md:left-8 z-20">
            <button 
                onClick={onBack}
                className="flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur-md text-white px-4 py-2 rounded-full font-bold transition-all"
            >
                <ArrowLeft className="w-5 h-5" /> Voltar
            </button>
        </div>
        <div className="absolute bottom-0 left-0 w-full p-6 md:p-12">
            <div className="container mx-auto">
                <span className="inline-block bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-lg mb-4 shadow-lg">
                    {news.category}
                </span>
                <h1 className="text-3xl md:text-5xl font-bold text-white mb-4 max-w-4xl leading-tight drop-shadow-lg">
                    {news.title}
                </h1>
                <div className="flex items-center gap-6 text-white/80 text-sm font-medium">
                    <span className="flex items-center gap-2"><Calendar className="w-4 h-4" /> {news.date}</span>
                    {news.author && <span className="flex items-center gap-2"><User className="w-4 h-4" /> {news.author}</span>}
                </div>
            </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-12 grid grid-cols-1 lg:grid-cols-12 gap-12">
        <div className="lg:col-span-8">
            <div className="prose prose-lg prose-slate max-w-none">
                <p className="lead text-xl text-slate-600 font-medium border-l-4 border-yellow-500 pl-4 mb-8">
                    {news.excerpt}
                </p>
                <div className="text-slate-700 whitespace-pre-line leading-relaxed">
                    {news.content || "Conteúdo completo da notícia indisponível na visualização de demonstração."}
                </div>
            </div>
            
            <div className="mt-12 pt-8 border-t border-slate-100 flex items-center justify-between">
                <span className="font-bold text-slate-800">Gostou? Compartilhe:</span>
                <div className="flex gap-3">
                    <button className="p-2 bg-blue-50 text-blue-600 rounded-full hover:bg-blue-100 transition-colors"><Share2 className="w-5 h-5" /></button>
                </div>
            </div>
        </div>

        {/* Sidebar */}
        <div className="lg:col-span-4 space-y-8">
            <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100">
                <h3 className="font-bold text-lg text-slate-800 mb-4">Relacionados</h3>
                <ul className="space-y-4">
                    <li className="flex gap-3 items-start group cursor-pointer">
                        <div className="w-20 h-20 bg-slate-200 rounded-lg overflow-hidden flex-shrink-0">
                            <img src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=200&q=80" className="w-full h-full object-cover group-hover:scale-110 transition-transform" alt="" />
                        </div>
                        <div>
                            <span className="text-[10px] font-bold text-blue-600 uppercase">Capacitação</span>
                            <h4 className="text-sm font-bold text-slate-700 leading-snug group-hover:text-blue-900">Workshop de Gestão Financeira</h4>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
      </div>
    </div>
  );
};

export default NewsDetail;
