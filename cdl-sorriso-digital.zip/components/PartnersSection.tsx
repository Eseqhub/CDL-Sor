
import React from 'react';
import { ArrowRight, Phone, MapPin, Tag, CheckCircle2 } from 'lucide-react';
import { PARTNERS_DATA } from '../constants';

const PartnersSection: React.FC = () => {
  return (
    <section className="py-16 bg-white border-b border-slate-100 overflow-hidden" id="clube-de-vantagens">
      <div className="container mx-auto px-4 mb-10">
        <div className="max-w-4xl">
            <span className="text-blue-600 font-bold tracking-wider text-sm uppercase mb-2 block">Clube de Vantagens</span>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">Convênios & Benefícios</h2>
            <p className="text-slate-500 text-lg leading-relaxed">
                Com ele você garante descontos exclusivos para associados e colaboradores numa rede que não para de crescer e já tem <span className="font-bold text-blue-600">mais de 50 conveniados</span>.
            </p>
        </div>
      </div>

      {/* Infinite Scroll Container */}
      <div className="relative w-full group/track">
        {/* Gradient Masks */}
        <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none"></div>
        <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none"></div>

        <div className="flex w-max animate-[marquee_40s_linear_infinite] group-hover/track:[animation-play-state:paused] hover:[animation-play-state:paused]">
            {/* Render the list twice to create seamless loop */}
            {[...PARTNERS_DATA, ...PARTNERS_DATA].map((partner, index) => (
                <div 
                    key={`${partner.id}-${index}`} 
                    className="w-[280px] md:w-[300px] mx-3 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl hover:border-blue-200 transition-all duration-300 flex flex-col transform hover:-translate-y-1 cursor-pointer"
                >
                    {/* Image Area */}
                    <div className="h-32 relative bg-slate-100 rounded-t-2xl overflow-hidden">
                        <img src={partner.image} alt={partner.name} className="w-full h-full object-cover grayscale group-hover/track:grayscale-0 transition-all duration-500" />
                        <div className="absolute top-3 right-3">
                            <span className="bg-yellow-400 text-blue-900 text-[10px] font-bold px-2 py-1 rounded-full shadow-sm uppercase tracking-wide flex items-center gap-1">
                                <Tag className="w-3 h-3" />
                                {partner.discount}
                            </span>
                        </div>
                    </div>

                    {/* Content */}
                    <div className="p-5 flex flex-col flex-1">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">{partner.category}</span>
                        <h3 className="font-bold text-slate-800 text-lg mb-3 text-blue-900 transition-colors line-clamp-1">{partner.name}</h3>
                        
                        <div className="mt-auto space-y-2">
                            <div className="flex items-center gap-2 text-sm text-slate-500">
                                <Phone className="w-3.5 h-3.5 text-blue-400" />
                                <span>(66) {partner.phone}</span>
                            </div>
                            {partner.address && (
                                <div className="flex items-center gap-2 text-sm text-slate-500">
                                    <MapPin className="w-3.5 h-3.5 text-blue-400" />
                                    <span className="line-clamp-1">{partner.address}</span>
                                </div>
                            )}
                        </div>

                        <button className="mt-4 w-full py-2 rounded-lg bg-slate-50 text-slate-600 font-bold text-xs hover:bg-blue-600 hover:text-white transition-all flex items-center justify-center gap-2 group/btn">
                            Utilizar Convênio <ArrowRight className="w-3 h-3 group-hover/btn:translate-x-1 transition-transform" />
                        </button>
                    </div>
                </div>
            ))}
        </div>
      </div>

      <style>{`
        @keyframes marquee {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }
      `}</style>
    </section>
  );
};

export default PartnersSection;
