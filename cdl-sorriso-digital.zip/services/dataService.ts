
import { supabase } from './supabaseClient';
import { NEWS_DATA, BUSINESS_DATA, PARTNERS_DATA, BOARD_MEMBERS, COLLABORATORS, GALLERY_IMAGES, PRODUCTS_DATA } from '../constants';

// --- UPLOAD DE IMAGENS ---
export const uploadImage = async (file: File, folder: string = 'general'): Promise<string | null> => {
  try {
    const fileExt = file.name.split('.').pop();
    const fileName = `${folder}/${Date.now()}.${fileExt}`;
    
    // Tenta primeiro no bucket 'Images' (Maiúsculo - como criado pelo usuário)
    // O Supabase diferencia maiúsculas de minúsculas no nome do bucket
    let { data, error } = await supabase.storage
      .from('Images') 
      .upload(fileName, file);

    // Se der erro (talvez o bucket seja minúsculo ou não exista 'Images'), tenta 'images'
    if (error) {
        console.warn("Tentativa no bucket 'Images' falhou, tentando 'images'...", error.message);
        const retry = await supabase.storage.from('images').upload(fileName, file);
        if (retry.error) {
            console.error("Erro final no upload:", retry.error);
            throw retry.error;
        }
    }

    // Tenta pegar URL pública do 'Images'
    const publicUrlData = supabase.storage.from('Images').getPublicUrl(fileName);
    
    // Se a URL gerada for do bucket errado, tenta o minúsculo
    if (error && !publicUrlData.data.publicUrl.includes('Images')) {
         const retryData = supabase.storage.from('images').getPublicUrl(fileName);
         return retryData.data.publicUrl;
    }

    return publicUrlData.data.publicUrl;
  } catch (error) {
    console.error("Erro critico no upload:", error);
    alert("Erro ao fazer upload. Verifique se o bucket 'Images' está criado e marcado como PUBLIC no Supabase.");
    return null;
  }
};

// --- FUNÇÕES GENÉRICAS DE CRUD ---

// BUSCAR (READ)
export const fetchItems = async (table: string, fallbackData: any[]) => {
  try {
    const { data, error } = await supabase
      .from(table)
      .select('*')
      .order('created_at', { ascending: false }); 

    if (error) {
        console.warn(`Tabela ${table} não encontrada ou erro de permissão. Usando dados locais.`);
        return fallbackData;
    }
    return data && data.length > 0 ? data : fallbackData;
  } catch (error) {
    console.warn(`Erro de conexão ao buscar ${table}. Usando dados locais.`, error);
    return fallbackData;
  }
};

// CRIAR (CREATE)
export const createItem = async (table: string, item: any) => {
  // Remove o ID se for gerado automaticamente pelo banco, ou mantenha se for UUID gerado no front
  const { id, ...dataToSave } = item; 
  
  const { data, error } = await supabase.from(table).insert([dataToSave]).select();
  
  if (error) {
      console.error(`Erro ao criar em ${table}:`, error);
      throw error;
  }
  return data?.[0];
};

// ATUALIZAR (UPDATE)
export const updateItem = async (table: string, id: string, updates: any) => {
  const { data, error } = await supabase.from(table).update(updates).eq('id', id).select();
  
  if (error) {
      console.error(`Erro ao atualizar em ${table}:`, error);
      throw error;
  }
  return data?.[0];
};

// DELETAR (DELETE)
export const deleteItem = async (table: string, id: string) => {
  const { error } = await supabase.from(table).delete().eq('id', id);
  if (error) {
      console.error(`Erro ao deletar de ${table}:`, error);
      throw error;
  }
  return true;
};


// --- HELPERS ESPECÍFICOS ---

export const getNoticias = () => fetchItems('news', NEWS_DATA);
export const getEmpresas = () => fetchItems('businesses', BUSINESS_DATA); 
export const getParceiros = () => fetchItems('partners', PARTNERS_DATA);
export const getDiretoria = () => fetchItems('board_members', BOARD_MEMBERS);
export const getColaboradores = () => fetchItems('team_members', COLLABORATORS);
export const getGaleria = () => fetchItems('gallery', GALLERY_IMAGES);
export const getProdutos = () => fetchItems('products', PRODUCTS_DATA);

// Clima e API Externa
export const fetchWeather = async () => {
  const API_KEY = process.env.REACT_APP_WEATHER_KEY;
  if (!API_KEY) return { temp: 32, condition: 'Ensolarado' };

  try {
    const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=Sorriso,BR&units=metric&lang=pt_br&appid=${API_KEY}`);
    const data = await response.json();
    return {
      temp: Math.round(data.main.temp),
      condition: data.weather[0].description
    };
  } catch (error) {
    return { temp: 32, condition: 'Indisponível' };
  }
};
