import { GoogleGenAI, Chat } from "@google/genai";
import { BUSINESS_DATA, NEWS_DATA } from '../constants';

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

let chatSession: Chat | null = null;

// Construct a system prompt containing the business context
const systemInstruction = `
Você é o Assistente Virtual da CDL Sorriso (Câmara de Dirigentes Lojistas).
Seu objetivo é ajudar usuários a encontrar empresas na cidade de Sorriso-MT, informar sobre notícias e serviços da CDL.
Seja cordial, use emojis moderadamente e mantenha um tom profissional e prestativo.

Aqui estão os dados atuais das empresas associadas (use isso para responder perguntas sobre "onde encontrar X"):
${JSON.stringify(BUSINESS_DATA.map(b => ({ name: b.name, type: b.category, desc: b.description, address: b.address })))}

Últimas Notícias e Eventos da CDL:
${JSON.stringify(NEWS_DATA)}

Serviços da CDL:
1. Certificado Digital: Emissão rápida e segura.
2. SPC/Serasa: Consultas de crédito para empresas.
3. CDL Celular: Planos corporativos.
4. Assessoria Jurídica: Apoio aos associados.

Se o usuário perguntar sobre algo fora desse contexto, explique educadamente que você só pode ajudar com assuntos relacionados à CDL Sorriso e comércio local.
`;

export const getChatSession = (): Chat => {
  if (!chatSession) {
    chatSession = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      },
    });
  }
  return chatSession;
};

export const sendMessageToGemini = async (message: string): Promise<string> => {
  try {
    const chat = getChatSession();
    const result = await chat.sendMessage({ message });
    return result.text || "Desculpe, não consegui processar sua solicitação no momento.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Ocorreu um erro ao conectar com o assistente. Tente novamente mais tarde.";
  }
};