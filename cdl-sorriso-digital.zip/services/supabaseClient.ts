
import { createClient } from '@supabase/supabase-js';

// Estes valores viriam do seu arquivo .env ou do painel da Vercel
const supabaseUrl = process.env.REACT_APP_SUPABASE_URL || '';
const supabaseKey = process.env.REACT_APP_SUPABASE_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseKey);
